# TripGuard hero integration contract

The uploaded skill packages remain source references; this executable specification
resolves disagreements for the Chennai–Singapore–Sydney hero. It does not silently
rewrite the original archives. The test report maps every hero acceptance ID.

## Changes from the original expectations

1. Step 7.1: a Tier B/C planning minimum supports **at risk**, not a confirmed
   missed connection. Tier A may support a missed classification. Arrival at or
   after onward departure supports Critical regardless of the planning threshold.
2. Rule R1 uses remaining connection time **less than** the minimum, not <=.
   Zero delay with exactly the required buffer does not trigger High.
3. Steps 7.2–7.3: shared booking references identify a group, not guaranteed
   rebooking entitlement. Coverage remains unverified until terms are checked.
   Transfer loss is conditional on the actual replacement arrival and provider
   terms, not an automatic consequence of an at-risk connection.
4. Airport exit time and driver waiting allowance are different fields. Neither
   is defaulted to 60 minutes. Unknown values remain null.
5. Steps 7.4–7.5: hotel arrival after midnight does not prove room loss or shift
   the reservation. Unknown cutoff and transfer time yield an at-risk consequence.
   Known cost precedes unknown cost within the same conditional-impact band.
6. High as well as Critical risks produce notifications. Critical escalation
   gets a new deduplication key. Recorded alerts are not claimed delivered.
7. The canonical executable schema includes prepaid transfers, nullable fares,
   source provenance, explicit typed graph edges and hotel-night nodes.
8. Traveller approval never overrides connector permissions. The action module
   prepares and validates drafts, but execution always fails closed. No outbound
   connector calls, payments or booking changes are implemented.

## Implemented boundary

- `fixtures.ts` contains four synthetic labelled booking messages and one malicious
  instruction-bearing message, a baseline, a delay feed and recovery fixtures.
- The deterministic parser supports this labelled grammar only; it is **not**
  a production email/PDF parser. No live mailbox was read.
- Runtime and tests call the same `runHero` function. The runtime is fixed to the
  fictional hero trip, single process, scheduled once per minute, with atomic
  local state replacement and alert deduplication across process restarts.
- Observation times remain the simulated December 4 time. The runtime's actual
  check time is separate; polling fixtures does not make their evidence live.
- The API is read-only and exposes synthetic data only. No real trip submission
  or personal data should be added until authentication and tenant isolation exist.
- Local state survives process restart in this development filesystem. It is
  **not** a production durability or multi-instance guarantee. Production needs
  durable shared storage, leases, bounded retries/backoff and monitored delivery.
- General graph traversal, arbitrary booking extraction, production notification
  policy, real inventory checks and live booking execution are outside this slice.

## Live sources

The integration search returned Google Maps Platform (API/MCP) for weather and
Jinko (MCP) for travel. Google Maps Platform was subsequently connected, but a
read-only weather request through its supported connector proxy returned HTTP
400: `Connector google-maps does not support proxy requests`. Weather remains
blocked; connection readiness alone did not establish usable runtime API access.
Jinko remains unconnected. No general flight-status connector
was returned by the flight-status/search/weather query. Catalog availability is
not proof of appropriate scopes, API support, flight coverage or freshness.

Live mode fails closed. No custom direct API, token or credential workaround is
used. A workspace admin must approve suitable read-only flight-status, weather
and inventory access and the permitted data flow before adapters are enabled.
Personal information other than business contact information must not be sent
through connectors. Third-party messages remain traveller-sent drafts; enabling
write access requires an admin-approved scope change.

### Weather connection verification

On 2026-11-22, tested the documented current-conditions lookup through the
connected Google Maps connector, using only the public Chennai airport
coordinates (12.99, 80.1693). No traveller, booking or personal location data was
sent. The proxy rejected the request before any usable weather response.

- API reference: https://developers.google.com/maps/documentation/weather/reference/rest/v1/currentConditions/lookup
- Public coordinate source: https://metar-taf.com/airport/VOMM-chennai-international-airport
- Required next step: ask the workspace admin for an approved weather connector
  with supported runtime read access. Do not request raw keys or bypass the
  connector. This is a connector capability blocker, not proof that Google
  Weather itself is unavailable.

## Run and inspect

`pnpm --filter @workspace/api-server test:hero`

Produces `generated-artifacts/tripguard/acceptance.html`, `acceptance.json` and
`hero-output.json`. Every criterion records PASS, FAIL or BLOCKED with evidence.
The integration harness does not invoke any external service.

`GET /api/tripguard/runtime` returns simulated runtime status.
`GET /api/tripguard/hero` returns the latest simulated assessment, or 503 if absent.

The original live exit criteria are not complete until approved live reads and
delivery are verified. A synthetic pass must never be relabelled as a live pass.
