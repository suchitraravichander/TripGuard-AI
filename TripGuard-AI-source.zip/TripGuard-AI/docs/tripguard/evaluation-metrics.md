# Travel Guardian evaluation protocol

The ten fixtures in `artifacts/api-server/src/tripguard/evaluation/scenarios.ts`
are test specifications, not ten newly implemented capabilities.
Run `pnpm --filter @workspace/api-server test:scenarios`.
Generated reports are in `generated-artifacts/tripguard/`.
PASS checks an implemented scenario slice; PARTIAL is incomplete; NOT_IMPLEMENTED
means the engine cannot receive/process that scenario. These are never scored
as successful complete journeys. FAIL means an executed assertion disagreed.

## Metrics and denominators

1. **Disruption detection:** event precision = TP/(TP+FP); recall = TP/(TP+FN).
   Match event kind, segment, travel date and relevance window, not just an alert
   or a severity label. Report supported-case coverage alongside results.
   The initial runner measures severity correctness on three supported cases,
   not the full event-detection accuracy of unsupported handlers.
2. **Impact accuracy:** report affected-booking precision and recall, plus exact-set
   match rate. Compare outcome classes separately (at risk versus missed/lost).
   Unknown cost is not zero. Score the independently authored expected set.
3. **Timeliness:** detection latency = detected_at - source_available_at;
   delivery latency = delivered_at - detected_at;
   actionable lead time = decision_deadline - delivered_at.
   A timely alert must precede the verified deadline by a scenario-specific,
   predeclared action buffer. Unknown deadlines/delivery times are unmeasurable,
   not zero latency or a pass. Fixture time cannot substitute for delivery time.
4. **Recovery quality:** fraction of recommendations satisfying hard constraints;
   verify source/time, route feasibility, inventory, fare and change terms.
   Rate usefulness separately with a human rubric: 0 unsafe/irrelevant,
   1 minimally helpful, 2 feasible with major caveats, 3 useful,
   4 best practical option with clearly explained tradeoffs.
   Synthetic feasibility does not verify live availability.
5. **Task completion:** completed expected workflows / all assigned workflows.
   Success can mean an acknowledged safe manual handoff or a verified resolution,
   not necessarily a purchase. An approval wait, missing handler or blocked
   provider is not automatically completion. Measure abandonment and blockers
   separately. Current suite does not establish any complete live workflow.
6. **False alerts:** report both false-positive rate FP/(FP+TN) and unnecessary
   alert share FP/(TP+FP); these have different denominators. Duplicate alerts
   should have a separate rate. An evidence-based warning is not false merely
   because the feared outcome was later avoided.

## Demo acceptance

- All ten scenarios must have explicit input, expected consequence, recovery
  behaviour and end state, even while their handlers remain missing.
- No invented forecasts, prices, booking losses or external delivery.
- No unsafe automatic execution; connector permissions remain binding.
- Report counts as fractions; do not advertise statistical accuracy from ten
  curated cases or from one negative test.
- Before reliability claims, expand the labelled dataset with benign delays,
  irrelevant weather warnings, withdrawn advisories, stale events, unrelated
  terminals and independent trips. Keep development fixtures separate from a
  held-out evaluation set and have a reviewer validate expected outcomes.
