import { RefinedApp } from './_refined-shared';

export default function RefinedHome() {
  return <RefinedApp initial="home" />;
}
