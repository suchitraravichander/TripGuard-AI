import './_refined.css';
import { fixture } from './_fixture';
import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, BedDouble, Car, Check, ChevronDown, ChevronRight, Plane, ShieldCheck } from 'lucide-react';

const run = fixture;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ZONES: Record<string, string> = { '+05:30': 'IST', '+08:00': 'SGT', '+11:00': 'AEDT' };

function parse(iso: string | null) {
  if (!iso) return null;
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}).*?([+-]\d{2}:\d{2}|Z)$/);
  if (!m) return null;
  return { time: `${m[4]}:${m[5]}`, date: `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]}`, zone: ZONES[m[6]] ?? m[6] };
}
function When({ iso }: { iso: string | null }) {
  const p = parse(iso);
  if (!p) return <span>Not stated</span>;
  return <time dateTime={iso!}><span className="mono font-medium">{p.time}</span> <span className="muted">{p.date} {p.zone}</span></time>;
}

/* Same dimensions for every option, so they can be compared row by row. */
const OPTS: Record<string, { short: string; affects: string; affectsN: number; uncertainty: string }> = {
  'option-2': { short: 'Another carrier, earlier', affects: 'later booking', affectsN: 1, uncertainty: 'Seat and fare unverified' },
  'option-1': { short: 'Example Air, later departure', affects: 'later booking', affectsN: 1, uncertainty: 'Seat and fare unverified' },
  'option-3': { short: 'Next-day departure', affects: 'later bookings', affectsN: 2, uncertainty: 'Seat and fare unverified' },
};
const ORDER = ['option-2', 'option-1', 'option-3'];
const opt = (id: string) => run.options.find((o) => o.id === id)!;

/* ---------- shell ---------- */
function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="rf">
      <header className="border-b border-[hsl(var(--line))] bg-[hsl(var(--surface))]">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 md:px-6">
          <div className="flex items-center gap-2 font-bold"><ShieldCheck className="h-5 w-5 text-[hsl(var(--teal))]" aria-hidden /> TripGuard</div>
          <div className="flex items-center gap-2 text-xs">
            <span className="chip chip-line">Simulation</span>
            <span className="mono muted hidden sm:inline">Observed 13:15 4 Dec SGT</span>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6 md:px-6">{children}</main>
    </div>
  );
}

function Activity() {
  return (
    <details className="panel text-sm">
      <summary className="flex items-center justify-between px-4 py-3 font-medium">
        How TripGuard got here <ChevronDown className="chev h-4 w-4" aria-hidden />
      </summary>
      <ol className="space-y-1.5 border-t border-[hsl(var(--line))] px-4 py-3">
        {run.activity.map((a, i) => (
          <li key={a} className="flex items-center gap-2"><span className="mono muted text-xs">{i + 1}</span>{a}</li>
        ))}
      </ol>
    </details>
  );
}

function PreferenceBanner({ chosen, onClear }: { chosen: string | null; onClear: () => void }) {
  return (
    <div aria-live="polite">
      {chosen && (
        <div className="fade panel flex flex-wrap items-center justify-between gap-3 border-[hsl(var(--teal)/.35)] bg-[hsl(var(--teal-soft))] px-4 py-3 text-sm">
          <p><strong>Your preference: {opt(chosen).title}.</strong> Saved in this preview until reload. Not booked — your current bookings and the connection risk are unchanged.</p>
          <button className="btn btn-ghost" onClick={onClear}>Clear</button>
        </div>
      )}
    </div>
  );
}

/* ---------- home ---------- */
const SEGS = [
  { id: 'seg_001', Icon: Plane, title: 'EX101 Chennai → Singapore', status: ['Delayed 40 min', 'chip-sand'], note: 'Now lands about 13:50 SGT (was 13:10).' },
  { id: 'seg_002', Icon: Plane, title: 'EX212 Singapore → Sydney', status: ['At risk', 'chip-coral'], note: '50 min to connect. 90 min is our planning guide, not the airline minimum.' },
  { id: 'seg_003', Icon: BedDouble, title: 'Harbour View Hotel', status: ['May be affected', 'chip-coral'], note: 'Late check-in cutoff unknown.' },
  { id: 'seg_004', Icon: Car, title: 'Airport pickup', status: ['May be affected', 'chip-coral'], note: 'Driver wait time unknown. Prepaid AUD 65, non-refundable.' },
] as const;

function Home({ openAlert, chosen, clear }: { openAlert: () => void; chosen: string | null; clear: () => void }) {
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { heading.current?.focus({ preventScroll: true }); }, []);
  const seg = (id: string) => run.segments.find((s) => s.id === id)!;
  return (
    <div className="grid gap-5 md:grid-cols-[1fr_1.15fr]">
      <div className="space-y-4">
        <section className="panel fade overflow-hidden" aria-labelledby="h-status">
          <div className="border-l-4 border-[hsl(var(--coral))] p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="label">Trip status · 4–6 Dec</span>
              <span className="chip chip-coral">High risk</span>
            </div>
            <h1 id="h-status" ref={heading} tabIndex={-1} className="mt-2 text-xl font-bold leading-snug">Your Singapore connection is at risk</h1>
            <p className="mt-1 muted">EX101 is 40 min late, leaving 50 min to make EX212. Not confirmed missed.</p>
            <p className="mt-3 text-sm"><span className="chip chip-sand">Review now</span> <span className="muted">Airline rebooking deadline unknown.</span></p>
            <button className="btn btn-primary mt-4 w-full justify-center sm:w-auto" onClick={openAlert}>
              See what to do <ChevronRight className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </section>

        <PreferenceBanner chosen={chosen} onClear={clear} />

        <section className="panel" aria-labelledby="h-next">
          <h2 id="h-next" className="label px-4 pt-4">Upcoming bookings</h2>
          <ul className="divide-y divide-[hsl(var(--line))] text-sm">
            <li className="flex justify-between gap-3 px-4 py-3"><span>EX212 departs</span><When iso={seg('seg_002').start} /></li>
            <li className="flex justify-between gap-3 px-4 py-3"><span>EX212 lands Sydney</span><When iso={seg('seg_002').end} /></li>
            <li className="flex justify-between gap-3 px-4 py-3"><span>Airport pickup</span><When iso={seg('seg_004').start} /></li>
            <li className="flex justify-between gap-3 px-4 py-3"><span>Hotel checkout</span><When iso={seg('seg_003').end} /></li>
          </ul>
        </section>
        <Activity />
      </div>

      <section className="panel fade p-4" aria-labelledby="h-tl">
        <h2 id="h-tl" className="label mb-2">Timeline</h2>
        <ol>
          {SEGS.map(({ id, Icon, title, status, note }, i) => {
            const s = seg(id);
            return (
              <li key={id} className="relative flex gap-3 pb-1">
                <div className="flex flex-col items-center">
                  <span className="grid h-8 w-8 place-items-center rounded-full bg-[hsl(var(--teal-soft))] text-[hsl(var(--teal))]"><Icon className="h-4 w-4" aria-hidden /></span>
                  {i < SEGS.length - 1 && <span className="w-px flex-1 bg-[hsl(var(--line))]" aria-hidden />}
                </div>
                <details className="mb-2 flex-1 rounded-lg px-2 py-1 hover:bg-[hsl(var(--bg))]">
                  <summary className="py-1">
                    <span className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-semibold">{title}</span>
                      <span className={`chip ${status[1]}`}>{status[0]}</span>
                    </span>
                    <span className="block text-sm"><When iso={s.start} />{s.end && <> <span className="muted">→</span> <When iso={id === 'seg_001' ? '2026-12-04T13:50:00+08:00' : s.end} /></>}</span>
                    {id === 'seg_001' && <span className="block text-xs muted">Estimated arrival · scheduled 13:10 SGT</span>}
                  </summary>
                  <p className="pb-1 text-sm muted">{note} Ref {s.bookingId.split(':')[1]}.</p>
                </details>
              </li>
            );
          })}
          <li className="flex gap-3">
            <span className="grid h-8 w-8 place-items-center rounded-full border border-dashed border-[hsl(var(--line))]"><Plane className="h-4 w-4 rotate-180 opacity-40" aria-hidden /></span>
            <p className="px-2 py-1.5 text-sm muted">No return booking in this trip.</p>
          </li>
        </ol>
      </section>
    </div>
  );
}

/* ---------- alert ---------- */
function Compare({ chosen, onPick, onClear }: { chosen: string | null; onPick: (id: string) => void; onClear: () => void }) {
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {ORDER.map((id) => {
        const o = opt(id); const m = OPTS[id]; const isChosen = chosen === id;
        return (
          <article key={id} aria-labelledby={`o-${id}`} className={`panel flex flex-col p-4 ${isChosen ? 'outline outline-2 outline-[hsl(var(--teal))]' : ''}`}>
            <div className="flex min-h-6 flex-wrap gap-1.5">
              {o.recommended && <span className="chip chip-teal">Recommended</span>}
              {isChosen && <span className="chip chip-sand"><Check className="h-3 w-3" aria-hidden />Your preference</span>}
            </div>
            <h3 id={`o-${id}`} className="mt-2 font-semibold">{m.short}</h3>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between gap-2"><dt className="muted">Arrive Sydney</dt><dd><When iso={o.arrival} /></dd></div>
              <div className="flex justify-between gap-2"><dt className="muted">Est. cost</dt><dd className="mono">AUD {o.cost}</dd></div>
              <div className="flex justify-between gap-2"><dt className="muted">Affects</dt><dd className="text-right">{m.affectsN} {m.affects}</dd></div>
              <div className="flex justify-between gap-2"><dt className="muted">Uncertainty</dt><dd className="text-right">{m.uncertainty}</dd></div>
            </dl>
            <div className="mt-auto pt-4">
              {isChosen
                ? <button className="btn btn-ghost w-full justify-center" onClick={onClear}>Clear preference</button>
                : <button className="btn btn-ghost w-full justify-center" onClick={() => onPick(id)}>{chosen ? 'Change to this' : 'Prefer this'}</button>}
            </div>
          </article>
        );
      })}
    </div>
  );
}

function AlertView({ back, chosen, setChosen }: { back: () => void; chosen: string | null; setChosen: (v: string | null) => void }) {
  const head = useRef<HTMLHeadingElement>(null);
  const dlg = useRef<HTMLDialogElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  useEffect(() => { head.current?.focus(); }, []);
  useEffect(() => { if (pending && !dlg.current?.open) dlg.current?.showModal(); }, [pending]);
  const pick = (id: string) => { opener.current = document.activeElement as HTMLElement; setPending(id); };
  const close = () => { dlg.current?.close(); };
  const p = pending ? opt(pending) : null;

  return (
    <div className="space-y-5">
      <button className="btn btn-ghost" onClick={back}><ArrowLeft className="h-4 w-4" aria-hidden /> My trip</button>

      <section className="panel fade overflow-hidden" aria-labelledby="h-alert">
        <div className="border-l-4 border-[hsl(var(--coral))] p-5">
          <div className="flex flex-wrap gap-1.5"><span className="chip chip-coral">High risk · not confirmed missed</span><span className="chip chip-sand">Review now · airline deadline unknown</span></div>
          <h1 id="h-alert" ref={head} tabIndex={-1} className="mt-2 text-xl font-bold">EX101 delayed 40 minutes</h1>
          <dl className="mt-3 grid gap-3 text-sm sm:grid-cols-2">
            <div><dt className="label">What happened</dt><dd>Lands Singapore about <span className="mono">13:50</span> SGT instead of <span className="mono">13:10</span>.</dd></div>
            <div><dt className="label">Why it matters to you</dt><dd>EX212 leaves <span className="mono">14:40</span> SGT — 50 min to connect. Our 90 min planning guide is not the airline minimum.</dd></div>
            <div><dt className="label">Affected</dt><dd>EX212 connection · Harbour View Hotel (cutoff unknown) · airport pickup (driver wait unknown). No return booking.</dd></div>
            <div><dt className="label">Your next step</dt><dd>Pick a preferred option below, then ask Example Air about rebooking. TripGuard cannot book.</dd></div>
          </dl>
        </div>
      </section>

      <section aria-labelledby="h-opts" className="space-y-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 id="h-opts" className="text-base font-bold">Three recovery options, compared</h2>
          <span className="text-xs muted">Estimates in AUD · availability unverified</span>
        </div>
        <details className="panel text-sm">
          <summary className="flex items-center justify-between px-4 py-3"><span><strong>Why we recommend the earlier carrier:</strong> earliest arrival with only one booking affected.</span><ChevronDown className="chev h-4 w-4 shrink-0" aria-hidden /></summary>
          <p className="border-t border-[hsl(var(--line))] px-4 py-3 muted">Ranked on demo constraints: arrive before 6 Dec, budget AUD 500. All three fit. The AUD 90 option is cheapest but arrives 19:00 and touches two bookings; AUD 120 arrives 50 min later than AUD 410.</p>
        </details>
        <PreferenceBanner chosen={chosen} onClear={() => setChosen(null)} />
        <Compare chosen={chosen} onPick={pick} onClear={() => setChosen(null)} />
      </section>

      <Activity />

      <dialog ref={dlg} aria-labelledby="dlg-h" onClose={() => { setPending(null); (opener.current?.isConnected ? opener.current : head.current)?.focus(); }}
        className="rf m-auto w-[min(92vw,420px)] rounded-2xl border border-[hsl(var(--line))] bg-[hsl(var(--surface))] p-0 text-[hsl(var(--ink))]" style={{ minHeight: 0 }}>
        {p && (
          <div className="p-5">
            <h2 id="dlg-h" className="text-lg font-bold">Save as your preference?</h2>
            <p className="mt-1 text-sm">{OPTS[p.id].short} · arrives <When iso={p.arrival} /> · est. AUD {p.cost}</p>
            <ul className="mt-3 space-y-1 text-sm muted">
              <li>This is a preference, not a reservation.</li>
              <li>Nothing is booked, paid or sent anywhere.</li>
              <li>Kept in this preview until reload. Your connection is still at risk.</li>
            </ul>
            <div className="mt-5 flex justify-end gap-2">
              <button className="btn btn-ghost" onClick={close}>Cancel</button>
              <button className="btn btn-primary" autoFocus onClick={() => { setChosen(p.id); close(); }}>Save preference</button>
            </div>
          </div>
        )}
      </dialog>
    </div>
  );
}

export function RefinedApp({ initial }: { initial: 'home' | 'alert' }) {
  const [view, setView] = useState(initial);
  const [chosen, setChosen] = useState<string | null>(null);
  useEffect(() => { window.scrollTo(0, 0); }, [view]);
  return (
    <Shell>
      {view === 'home'
        ? <Home openAlert={() => setView('alert')} chosen={chosen} clear={() => setChosen(null)} />
        : <AlertView back={() => setView('home')} chosen={chosen} setChosen={setChosen} />}
    </Shell>
  );
}
