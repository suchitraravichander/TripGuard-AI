import type { PrototypeRun } from './_types';
export const getGetPrototypeRunQueryKey = (id:string)=>[id];
export const useQueryClient = ()=>({setQueryData: (...args:unknown[])=>{}, invalidateQueries: (...args:unknown[])=>{}});
type Input = {id:string,data:{optionId?:string,minutes?:number,version?:number}};
const stub = ()=>({isError:false,isPending:false,variables:undefined as Input|undefined,mutate:(_input:Input,_options?:{onSuccess?:(r:PrototypeRun)=>void,onSettled?:()=>void})=>{}});
export const useSimulatePrototypeDelay = stub;
export const useSelectPrototypeOption = stub;
