import { TravellerApp } from './_shared';

export default function Alert() {
  return <TravellerApp initial="alert" />;
}
