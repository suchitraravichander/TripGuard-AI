import { RefinedApp } from './_refined-shared';

export default function RefinedAlert() {
  return <RefinedApp initial="alert" />;
}
