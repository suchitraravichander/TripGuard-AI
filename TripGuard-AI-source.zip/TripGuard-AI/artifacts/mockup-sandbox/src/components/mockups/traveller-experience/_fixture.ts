import type { PrototypeRun, SampleEmail } from './_types';
export const fixture: PrototypeRun = {
  "id": "2be9367b-4a2a-4a50-9eeb-f9ef055a67cc",
  "version": 5,
  "phase": "action_required",
  "createdAt": "2026-11-22T10:21:17.172Z",
  "dueAt": null,
  "delayMinutes": 40,
  "riskLevel": "High",
  "remainingMinutes": 50,
  "reasoning": "Your inbound flight is delayed 40 minutes. Your Singapore connection now has 50 minutes instead of 90. The 90-minute planning allowance is not a verified airline minimum. Hotel and transfer impact remain at risk, not confirmed lost.",
  "segments": [
    {
      "id": "seg_001",
      "type": "flight",
      "provider": "Example Air",
      "service": "EX101",
      "origin": "MAA",
      "destination": "SIN",
      "start": "2026-12-04T06:10:00+05:30",
      "end": "2026-12-04T13:10:00+08:00",
      "bookingId": "Example Air:SIM7F2"
    },
    {
      "id": "seg_002",
      "type": "flight",
      "provider": "Example Air",
      "service": "EX212",
      "origin": "SIN",
      "destination": "SYD",
      "start": "2026-12-04T14:40:00+08:00",
      "end": "2026-12-04T22:50:00+11:00",
      "bookingId": "Example Air:SIM7F2"
    },
    {
      "id": "seg_003",
      "type": "hotel",
      "provider": "Harbour View Hotel",
      "service": null,
      "origin": "Sydney",
      "destination": "Sydney",
      "start": "2026-12-04T15:00:00+11:00",
      "end": "2026-12-06T11:00:00+11:00",
      "bookingId": "Harbour View Hotel:HV5520"
    },
    {
      "id": "seg_004",
      "type": "prepaid_transfer",
      "provider": "Example Transfers",
      "service": null,
      "origin": "SYD",
      "destination": "Sydney",
      "start": "2026-12-05T00:30:00+11:00",
      "end": null,
      "bookingId": "Example Transfers:T9981"
    }
  ],
  "impacts": [
    {
      "segmentId": "seg_003",
      "classification": "at_risk",
      "reason": "Later arrival may affect your first hotel night. Check-in cutoff is unknown.",
      "amount": null,
      "currency": null
    },
    {
      "segmentId": "seg_004",
      "classification": "at_risk",
      "reason": "The 00:30 airport pickup may need to move. Driver wait time is unknown.",
      "amount": 65,
      "currency": "AUD"
    }
  ],
  "options": [
    {
      "id": "option-2",
      "title": "Earlier arrival · another carrier",
      "arrival": "2026-12-05T06:40:00+11:00",
      "cost": 410,
      "currency": "AUD",
      "recommended": true,
      "reason": "Earliest arrival among options affecting one downstream booking. Availability and fare unverified."
    },
    {
      "id": "option-1",
      "title": "Later departure · Example Air",
      "arrival": "2026-12-05T07:30:00+11:00",
      "cost": 120,
      "currency": "AUD",
      "recommended": false,
      "reason": "Lower estimated price, arrives 50 minutes later. Availability unverified."
    },
    {
      "id": "option-3",
      "title": "Next-day departure",
      "arrival": "2026-12-05T19:00:00+11:00",
      "cost": 90,
      "currency": "AUD",
      "recommended": false,
      "reason": "Lowest estimated price but affects two downstream bookings. Availability unverified."
    }
  ],
  "alerts": [
    {
      "id": "mock-alert",
      "level": "High",
      "text": "EX101 is delayed 40 minutes. Your Singapore connection is at risk. Compare three recovery options before changing your bookings.",
      "createdAt": "2026-12-04T05:15:00Z"
    }
  ],
  "selectedOptionId": null,
  "itineraryJson": "{\n  \"segments\": [\n    {\n      \"id\": \"seg_001\",\n      \"type\": \"flight\",\n      \"provider\": \"Example Air\",\n      \"bookingId\": \"Example Air:SIM7F2\",\n      \"service\": \"EX101\",\n      \"start\": \"2026-12-04T06:10:00+05:30\",\n      \"end\": \"2026-12-04T13:10:00+08:00\",\n      \"startZone\": \"Asia/Kolkata\",\n      \"endZone\": \"Asia/Singapore\",\n      \"origin\": \"MAA\",\n      \"destination\": \"SIN\",\n      \"source\": {\n        \"id\": \"sample-confirmation-email\",\n        \"sentAt\": \"2026-11-20T09:00:00Z\"\n      },\n      \"fare\": null,\n      \"cost\": null,\n      \"refundable\": \"unknown\",\n      \"airportExitMinutes\": null,\n      \"driverWaitMinutes\": null,\n      \"hotelCutoff\": null\n    },\n    {\n      \"id\": \"seg_002\",\n      \"type\": \"flight\",\n      \"provider\": \"Example Air\",\n      \"bookingId\": \"Example Air:SIM7F2\",\n      \"service\": \"EX212\",\n      \"start\": \"2026-12-04T14:40:00+08:00\",\n      \"end\": \"2026-12-04T22:50:00+11:00\",\n      \"startZone\": \"Asia/Singapore\",\n      \"endZone\": \"Australia/Sydney\",\n      \"origin\": \"SIN\",\n      \"destination\": \"SYD\",\n      \"source\": {\n        \"id\": \"sample-confirmation-email\",\n        \"sentAt\": \"2026-11-20T09:00:00Z\"\n      },\n      \"fare\": null,\n      \"cost\": null,\n      \"refundable\": \"unknown\",\n      \"airportExitMinutes\": null,\n      \"driverWaitMinutes\": null,\n      \"hotelCutoff\": null\n    },\n    {\n      \"id\": \"seg_003\",\n      \"type\": \"hotel\",\n      \"provider\": \"Harbour View Hotel\",\n      \"bookingId\": \"Harbour View Hotel:HV5520\",\n      \"service\": null,\n      \"start\": \"2026-12-04T15:00:00+11:00\",\n      \"end\": \"2026-12-06T11:00:00+11:00\",\n      \"startZone\": \"Australia/Sydney\",\n      \"endZone\": \"Australia/Sydney\",\n      \"origin\": \"Sydney\",\n      \"destination\": \"Sydney\",\n      \"source\": {\n        \"id\": \"sample-confirmation-email\",\n        \"sentAt\": \"2026-11-20T09:00:00Z\"\n      },\n      \"fare\": null,\n      \"cost\": null,\n      \"refundable\": \"unknown\",\n      \"airportExitMinutes\": null,\n      \"driverWaitMinutes\": null,\n      \"hotelCutoff\": null\n    },\n    {\n      \"id\": \"seg_004\",\n      \"type\": \"prepaid_transfer\",\n      \"provider\": \"Example Transfers\",\n      \"bookingId\": \"Example Transfers:T9981\",\n      \"service\": null,\n      \"start\": \"2026-12-05T00:30:00+11:00\",\n      \"end\": null,\n      \"startZone\": \"Australia/Sydney\",\n      \"endZone\": null,\n      \"origin\": \"SYD\",\n      \"destination\": \"Sydney\",\n      \"source\": {\n        \"id\": \"sample-confirmation-email\",\n        \"sentAt\": \"2026-11-20T09:00:00Z\"\n      },\n      \"fare\": null,\n      \"cost\": {\n        \"amount\": 65,\n        \"currency\": \"AUD\"\n      },\n      \"refundable\": \"no\",\n      \"airportExitMinutes\": null,\n      \"driverWaitMinutes\": null,\n      \"hotelCutoff\": null\n    }\n  ],\n  \"nodes\": [\n    {\n      \"id\": \"seg_001\",\n      \"type\": \"flight\"\n    },\n    {\n      \"id\": \"seg_002\",\n      \"type\": \"flight\"\n    },\n    {\n      \"id\": \"seg_003\",\n      \"type\": \"hotel\"\n    },\n    {\n      \"id\": \"seg_004\",\n      \"type\": \"prepaid_transfer\"\n    },\n    {\n      \"id\": \"layover_sin\",\n      \"type\": \"layover\"\n    },\n    {\n      \"id\": \"night_2026-12-04\",\n      \"type\": \"hotel_night\",\n      \"date\": \"2026-12-04\"\n    },\n    {\n      \"id\": \"night_2026-12-05\",\n      \"type\": \"hotel_night\",\n      \"date\": \"2026-12-05\"\n    }\n  ],\n  \"edges\": [\n    {\n      \"from\": \"seg_001\",\n      \"to\": \"seg_002\",\n      \"type\": \"connection\"\n    },\n    {\n      \"from\": \"seg_002\",\n      \"to\": \"seg_004\",\n      \"type\": \"transfer_pickup\"\n    },\n    {\n      \"from\": \"seg_002\",\n      \"to\": \"seg_003\",\n      \"type\": \"hotel_checkin\"\n    },\n    {\n      \"from\": \"seg_003\",\n      \"to\": \"night_2026-12-04\",\n      \"type\": \"night_coverage\"\n    },\n    {\n      \"from\": \"seg_003\",\n      \"to\": \"night_2026-12-05\",\n      \"type\": \"night_coverage\"\n    }\n  ],\n  \"ignoredMessages\": [],\n  \"flags\": [],\n  \"disclosure\": \"Synthetic mailbox only. Gmail was not searched. Instruction-bearing unsupported messages were ignored.\"\n}",
  "activity": [
    "Monitoring your flight",
    "Detected schedule change",
    "Analysed connection",
    "Checked alternatives",
    "Found 3 recovery options"
  ]
};
export const sample: SampleEmail = {
  "subject": "Your Chennai–Singapore–Sydney trip is confirmed · SIM7F2",
  "from": "Example Travel <bookings@example.invalid>",
  "body": "Hello traveller,\n\nYour sample travel itinerary is confirmed. All bookings below are fictional.\n\n[Booking]\nType: flight\nProvider: Example Air\nConfirmation: SIM7F2\nService: EX101\nOrigin: MAA\nDestination: SIN\nStart: 2026-12-04T06:10:00+05:30\nEnd: 2026-12-04T13:10:00+08:00\nStartZone: Asia/Kolkata\nEndZone: Asia/Singapore\n\n[Booking]\nType: flight\nProvider: Example Air\nConfirmation: SIM7F2\nService: EX212\nOrigin: SIN\nDestination: SYD\nStart: 2026-12-04T14:40:00+08:00\nEnd: 2026-12-04T22:50:00+11:00\nStartZone: Asia/Singapore\nEndZone: Australia/Sydney\n\n[Booking]\nType: hotel\nProvider: Harbour View Hotel\nConfirmation: HV5520\nOrigin: Sydney\nDestination: Sydney\nStart: 2026-12-04T15:00:00+11:00\nEnd: 2026-12-06T11:00:00+11:00\nStartZone: Australia/Sydney\nEndZone: Australia/Sydney\n\n[Booking]\nType: prepaid_transfer\nProvider: Example Transfers\nConfirmation: T9981\nOrigin: SYD\nDestination: Sydney\nStart: 2026-12-05T00:30:00+11:00\nStartZone: Australia/Sydney\nCost: 65\nCurrency: AUD\nRefundable: no\n\nThis is a demonstration email, not a real reservation."
};