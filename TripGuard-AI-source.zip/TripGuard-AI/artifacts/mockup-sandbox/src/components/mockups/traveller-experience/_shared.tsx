import './_group.css';
import './_traveller.css';
import { fixture } from './_fixture';
import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle, ArrowLeft, ArrowRight, BedDouble, Car, Check, ChevronDown, Clock, Info, Plane, ShieldCheck, X,
} from 'lucide-react';

const run = fixture;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ZONES: Record<string, string> = { '+05:30': 'Chennai · IST', '+08:00': 'Singapore · SGT', '+11:00': 'Sydney · AEDT' };

function parse(iso: string | null) {
  if (!iso) return null;
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}).*?([+-]\d{2}:\d{2}|Z)$/);
  if (!m) return null;
  return { time: `${m[4]}:${m[5]}`, date: `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]}`, zone: ZONES[m[6]] ?? m[6] };
}
export function When({ iso, zone = true }: { iso: string | null; zone?: boolean }) {
  const p = parse(iso);
  if (!p) return <span>Time not stated</span>;
  return (
    <time dateTime={iso!}>
      <span className="mono font-semibold">{p.time}</span> <span>{p.date}</span>
      {zone && <span className="text-[0.78em] text-[hsl(var(--mute))]"> · {p.zone}</span>}
    </time>
  );
}

const OPTION_META: Record<string, { tag: string; downstream: string; plain: string }> = {
  'option-2': { tag: 'Earliest arrival', downstream: 'Affects 1 later booking', plain: 'Another carrier gets you into Sydney first.' },
  'option-1': { tag: 'Lower estimate', downstream: 'Arrives 50 min later than the earliest', plain: 'Stay with Example Air on a later departure.' },
  'option-3': { tag: 'Lowest estimate', downstream: 'Affects 2 later bookings', plain: 'Fly the next day. Cheapest, but latest by far.' },
};

/* ---------------- shell ---------------- */
function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="tgx">
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 pt-6 md:px-8">
        <div className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[hsl(var(--ink))] text-[hsl(var(--amber))]"><ShieldCheck className="h-5 w-5" aria-hidden /></span>
          <span className="text-lg font-extrabold tracking-tight">TripGuard</span>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2 text-xs">
          <span className="mono rounded-full border border-dashed border-[hsl(var(--ink)/.3)] px-2.5 py-1 text-[hsl(var(--mute))]">Simulation · fictional bookings</span>
          <span className="mono hidden rounded-full bg-[hsl(var(--card2))] px-2.5 py-1 sm:inline">4 Dec · 13:15 Singapore</span>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-5 pb-16 pt-6 md:px-8">{children}</main>
    </div>
  );
}

/* ---------------- transparency ---------------- */
function HowWeGotHere() {
  return (
    <details className="group card p-0">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-4 text-sm font-semibold">
        <span className="flex items-center gap-2"><Info className="h-4 w-4 text-[hsl(var(--harbour))]" aria-hidden /> How TripGuard got here</span>
        <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" aria-hidden />
      </summary>
      <ol className="flex flex-wrap items-center gap-x-2 gap-y-2 border-t border-[hsl(var(--line))] px-5 py-4 text-sm">
        {run.activity.map((a, i) => (
          <li key={a} className="flex items-center gap-2">
            <span className="rounded-full bg-[hsl(var(--harbour-soft))] px-3 py-1 text-[hsl(var(--harbour))]">{a}</span>
            {i < run.activity.length - 1 && <ArrowRight className="h-3.5 w-3.5 text-[hsl(var(--mute))]" aria-hidden />}
          </li>
        ))}
      </ol>
    </details>
  );
}

/* ---------------- options ---------------- */
function Options({ chosen, setChosen, compact }: { chosen: string | null; setChosen: (id: string | null) => void; compact?: boolean }) {
  const [confirm, setConfirm] = useState<string | null>(null);
  const dlg = useRef<HTMLDialogElement>(null);
  useEffect(() => { if (confirm) dlg.current?.showModal(); else dlg.current?.close(); }, [confirm]);
  const opt = run.options.find((o) => o.id === confirm);
  const ordered = [...run.options].sort((a, b) => Number(b.recommended) - Number(a.recommended));
  return (
    <div>
      <div className={`grid gap-3 ${compact ? '' : 'lg:grid-cols-3'}`}>
        {ordered.map((o) => {
          const meta = OPTION_META[o.id];
          const isChosen = chosen === o.id;
          return (
            <article key={o.id} aria-labelledby={`t-${o.id}`}
              className={`card lift relative flex flex-col p-5 ${isChosen ? 'ring-2 ring-[hsl(var(--harbour))]' : o.recommended ? 'ring-2 ring-[hsl(var(--amber))]' : ''}`}>
              <div className="flex flex-wrap gap-1.5 text-[11px] font-semibold">
                {o.recommended && <span className="rounded-full bg-[hsl(var(--amber))] px-2.5 py-0.5">Suggested for you</span>}
                <span className="rounded-full bg-[hsl(var(--ink)/.07)] px-2.5 py-0.5">{meta.tag}</span>
                {isChosen && <span className="rounded-full bg-[hsl(var(--harbour))] px-2.5 py-0.5 text-[hsl(var(--paper))]">Your preference · not booked</span>}
              </div>
              <h3 id={`t-${o.id}`} className="mt-3 text-lg font-bold leading-tight">{o.title}</h3>
              <p className="mt-1 text-sm text-[hsl(var(--mute))]">{meta.plain}</p>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-xs text-[hsl(var(--mute))]">Arrive Sydney</dt><dd><When iso={o.arrival} zone={false} /> <span className="text-xs text-[hsl(var(--mute))]">AEDT</span></dd></div>
                <div><dt className="text-xs text-[hsl(var(--mute))]">Estimated cost</dt><dd className="mono font-semibold">AUD {o.cost.toFixed(2)}</dd></div>
              </dl>
              <p className="mt-3 text-xs text-[hsl(var(--mute))]">{meta.downstream}. Availability unverified.</p>
              <div className="mt-auto flex gap-2 pt-4">
                {isChosen ? (
                  <button onClick={() => setChosen(null)} className="inline-flex items-center gap-1.5 rounded-full border border-[hsl(var(--ink)/.25)] px-4 py-2 text-sm font-semibold">
                    <X className="h-4 w-4" aria-hidden /> Clear preference
                  </button>
                ) : (
                  <button onClick={() => setConfirm(o.id)} className="inline-flex items-center gap-1.5 rounded-full bg-[hsl(var(--ink))] px-4 py-2 text-sm font-semibold text-[hsl(var(--paper))]">
                    Prefer this option
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-[hsl(var(--mute))]">All prices are estimates in AUD. Nothing here is a purchase; your original bookings stay exactly as they are.</p>

      <dialog ref={dlg} onClose={() => setConfirm(null)} aria-labelledby="dlg-t"
        className="m-auto w-[min(92vw,460px)] rounded-2xl border border-[hsl(var(--line))] bg-[hsl(var(--card2))] p-0 text-[hsl(var(--ink))] backdrop:bg-[hsl(222_48%_17%/.45)]">
        {opt && (
          <div className="p-6">
            <h2 id="dlg-t" className="text-xl font-extrabold">Save “{opt.title}” as your preference?</h2>
            <ul className="mt-4 space-y-2 text-sm">
              <li className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--harbour))]" aria-hidden />Kept in this preview until you reload.</li>
              <li className="flex gap-2"><X className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--dusk))]" aria-hidden />Nothing is booked, paid or sent to an airline.</li>
              <li className="flex gap-2"><X className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--dusk))]" aria-hidden />Saving a preference does not resolve the connection risk.</li>
            </ul>
            <p className="mt-3 text-xs text-[hsl(var(--mute))]">Estimated AUD {opt.cost.toFixed(2)} · seat availability unverified.</p>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setConfirm(null)} className="rounded-full border border-[hsl(var(--ink)/.25)] px-4 py-2 text-sm font-semibold">Keep comparing</button>
              <button autoFocus onClick={() => { setChosen(opt.id); setConfirm(null); }} className="rounded-full bg-[hsl(var(--ink))] px-4 py-2 text-sm font-semibold text-[hsl(var(--paper))]">Save preference</button>
            </div>
          </div>
        )}
      </dialog>
    </div>
  );
}

function ChosenNote({ chosen, onClear }: { chosen: string | null; onClear: () => void }) {
  const o = run.options.find((x) => x.id === chosen);
  return (
    <div aria-live="polite">
      {o && (
        <div className="in card flex flex-wrap items-center justify-between gap-3 border-[hsl(var(--harbour)/.4)] bg-[hsl(var(--harbour-soft))] p-4 text-sm">
          <p><strong>Preference saved: {o.title}.</strong> Not booked. Your connection is still at risk — contact Example Air to act on it.</p>
          <button onClick={onClear} className="rounded-full border border-[hsl(var(--harbour)/.5)] px-3 py-1.5 font-semibold">Clear</button>
        </div>
      )}
    </div>
  );
}

/* ---------------- home ---------------- */
const segIcon = (t: string) => (t === 'hotel' ? BedDouble : t.includes('transfer') ? Car : Plane);
const SEG_STATE: Record<string, { label: string; tone: 'delay' | 'risk' | 'ok' }> = {
  seg_001: { label: 'Delayed 40 min', tone: 'delay' },
  seg_002: { label: 'Connection at risk', tone: 'risk' },
  seg_003: { label: 'Check-in may be late', tone: 'risk' },
  seg_004: { label: 'Pickup may need to move', tone: 'risk' },
};
const toneCls = { delay: 'bg-[hsl(var(--amber-soft))] text-[hsl(30_80%_28%)]', risk: 'bg-[hsl(var(--dusk-soft))] text-[hsl(var(--dusk))]', ok: 'bg-[hsl(var(--harbour-soft))] text-[hsl(var(--harbour))]' };
const SEG_TITLE: Record<string, string> = { seg_001: 'Chennai → Singapore', seg_002: 'Singapore → Sydney', seg_003: 'Harbour View Hotel', seg_004: 'Airport pickup' };

function Home({ openAlert, chosen, setChosen }: { openAlert: () => void; chosen: string | null; setChosen: (v: string | null) => void }) {
  return (
    <div className="space-y-8">
      <section className="in grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <div>
          <p className="text-sm font-semibold text-[hsl(var(--harbour))]">Chennai → Singapore → Sydney · 4–6 Dec</p>
          <h1 className="mt-2 text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl">Your first flight is running late. <span className="text-[hsl(var(--dusk))]">Your Singapore connection is tight.</span></h1>
          <p className="mt-4 max-w-xl text-[hsl(var(--mute))]">Your connection is at risk, not confirmed missed. We've compared three possible ways to reach Sydney so you can decide what to do next.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button onClick={openAlert} className="lift inline-flex items-center gap-2 rounded-full bg-[hsl(var(--ink))] px-5 py-3 font-semibold text-[hsl(var(--paper))]">Review what to do <ArrowRight className="h-4 w-4" aria-hidden /></button>
            <a href="#options" className="focusable inline-flex items-center rounded-full border border-[hsl(var(--ink)/.25)] px-5 py-3 font-semibold">See recovery options</a>
          </div>
        </div>
        <div className="card p-5" role="group" aria-label="Connection risk">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">Connection risk</span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[hsl(var(--dusk))] px-3 py-1 text-xs font-bold text-[hsl(var(--paper))]"><AlertTriangle className="h-3.5 w-3.5" aria-hidden /> High</span>
          </div>
          <div className="mt-5">
            <div className="flex items-baseline justify-between"><span className="mono text-4xl font-semibold">50 min</span><span className="text-sm text-[hsl(var(--mute))]">to connect in Singapore</span></div>
            <div className="relative mt-3 h-3 rounded-full bg-[hsl(var(--ink)/.08)]" aria-hidden>
              <div className="h-3 rounded-full bg-[hsl(var(--dusk))]" style={{ width: `${(50 / 90) * 100}%` }} />
              <span className="absolute -top-1 right-0 h-5 w-0.5 bg-[hsl(var(--ink))]" />
            </div>
            <div className="mt-1.5 flex justify-between text-xs text-[hsl(var(--mute))]"><span>was 90 min</span><span>90 min planning guide (unverified)</span></div>
          </div>
          <p className="mt-4 rounded-xl bg-[hsl(var(--amber-soft))] p-3 text-sm"><Clock className="mr-1 inline h-4 w-4" aria-hidden /> <strong>Review now.</strong> The airline's rebooking deadline is unknown.</p>
        </div>
      </section>

      <section aria-labelledby="h-alerts" className="in">
        <h2 id="h-alerts" className="sr-only">Important alert</h2>
        <button onClick={openAlert} className="lift card flex w-full items-start gap-4 p-5 text-left" aria-label="Open alert: EX101 delayed 40 minutes, connection at risk">
          <span className="breathe mt-1 h-3 w-3 shrink-0 rounded-full bg-[hsl(var(--dusk))]" aria-hidden />
          <span className="flex-1">
            <span className="block text-xs font-semibold text-[hsl(var(--dusk))]">Important · 13:15 4 Dec Singapore</span>
            <span className="mt-1 block text-lg font-bold leading-snug">EX101 is delayed 40 minutes. Your Singapore connection is at risk.</span>
            <span className="mt-1 block text-sm text-[hsl(var(--mute))]">Hotel check-in and airport pickup may be affected. Tap to see what to do.</span>
          </span>
          <ArrowRight className="mt-2 h-5 w-5 shrink-0" aria-hidden />
        </button>
      </section>

      <div className="grid gap-8 lg:grid-cols-[1.35fr_1fr]">
        <section aria-labelledby="h-tl" className="in">
          <h2 id="h-tl" className="mb-4 text-2xl font-extrabold tracking-tight">Your trip</h2>
          <ol className="relative space-y-3 before:absolute before:bottom-6 before:left-[21px] before:top-6 before:w-0.5 before:bg-[hsl(var(--ink)/.12)]">
            {run.segments.map((s, i) => {
              const Icon = segIcon(s.type);
              const st = SEG_STATE[s.id];
              return (
                <li key={s.id} className="relative flex gap-4">
                  <span className={`relative z-10 grid h-11 w-11 shrink-0 place-items-center rounded-full ${i === 0 ? 'bg-[hsl(var(--amber))]' : 'bg-[hsl(var(--card2))] ring-1 ring-[hsl(var(--line))]'}`}><Icon className="h-5 w-5" aria-hidden /></span>
                  <div className="card flex-1 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="font-bold">{SEG_TITLE[s.id]}</h3>
                      <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${toneCls[st.tone]}`}>{st.label}</span>
                    </div>
                    <p className="mt-1 text-sm"><When iso={s.start} />{s.end && <><span className="text-[hsl(var(--mute))]"> → </span><When iso={s.end} /></>}</p>
                    <p className="mt-1 text-xs text-[hsl(var(--mute))]">{s.provider}{s.service ? ` ${s.service}` : ''} · ref {s.bookingId.split(':')[1]}</p>
                    {s.id === 'seg_001' && <p className="mt-2 text-xs">New estimated landing about 13:50 Singapore.</p>}
                  </div>
                </li>
              );
            })}
            <li className="relative flex gap-4">
              <span className="relative z-10 grid h-11 w-11 shrink-0 place-items-center rounded-full border border-dashed border-[hsl(var(--ink)/.3)] bg-[hsl(var(--paper))]"><Plane className="h-5 w-5 rotate-180 opacity-50" aria-hidden /></span>
              <div className="flex-1 rounded-[18px] border border-dashed border-[hsl(var(--ink)/.25)] p-4 text-sm text-[hsl(var(--mute))]">No return booking found in your trip.</div>
            </li>
          </ol>
        </section>

        <aside className="space-y-6">
          <section aria-labelledby="h-up" className="in">
            <h2 id="h-up" className="mb-4 text-2xl font-extrabold tracking-tight">Up next</h2>
            <div className="card divide-y divide-[hsl(var(--line))]">
              {[
                ['EX212 Singapore → Sydney', run.segments[1].start, 'Departs'],
                ['Harbour View Hotel', run.segments[2].start, 'Check-in from'],
                ['Example Transfers pickup', run.segments[3].start, 'Pickup'],
              ].map(([t, iso, l]) => (
                <div key={t} className="p-4"><p className="font-semibold">{t}</p><p className="text-sm"><span className="text-[hsl(var(--mute))]">{l} </span><When iso={iso} /></p></div>
              ))}
            </div>
          </section>
          <section aria-labelledby="h-unk" className="card in p-5">
            <h2 id="h-unk" className="font-bold">Still unknown</h2>
            <ul className="mt-2 space-y-1.5 text-sm text-[hsl(var(--mute))]">
              <li>Airline minimum connection time (90 min is our planning guide)</li>
              <li>Hotel late check-in cutoff</li>
              <li>How long the driver will wait</li>
              <li>Airline rebooking deadline</li>
            </ul>
          </section>
          <HowWeGotHere />
        </aside>
      </div>

      <section id="options" aria-labelledby="h-opt" className="in scroll-mt-6 space-y-4">
        <div>
          <h2 id="h-opt" className="text-2xl font-extrabold tracking-tight">Recovery options</h2>
          <p className="text-sm text-[hsl(var(--mute))]">We suggest the earliest arrival with fewer knock-on effects — not the cheapest.</p>
        </div>
        <ChosenNote chosen={chosen} onClear={() => setChosen(null)} />
        <Options chosen={chosen} setChosen={setChosen} />
      </section>
    </div>
  );
}

/* ---------------- alert ---------------- */
function AlertView({ back, chosen, setChosen }: { back: () => void; chosen: string | null; setChosen: (v: string | null) => void }) {
  const head = useRef<HTMLHeadingElement>(null);
  useEffect(() => { head.current?.focus(); }, []);
  return (
    <div className="space-y-6">
      <button onClick={back} className="inline-flex items-center gap-1.5 text-sm font-semibold"><ArrowLeft className="h-4 w-4" aria-hidden /> Back to my trip</button>
      <section className="in card overflow-hidden">
        <div className="bg-[hsl(var(--ink))] p-6 text-[hsl(var(--paper))] md:p-8">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
            <span className="rounded-full bg-[hsl(var(--dusk))] px-3 py-1">High risk</span>
            <span className="rounded-full bg-[hsl(var(--amber))] px-3 py-1 text-[hsl(var(--ink))]">Review now · airline deadline unknown</span>
            <span className="mono opacity-70">Observed 13:15 4 Dec · Singapore</span>
          </div>
          <h1 ref={head} tabIndex={-1} className="mt-4 text-3xl font-extrabold leading-tight tracking-tight outline-none md:text-4xl">EX101 is delayed 40 minutes.</h1>
          <p className="mt-2 max-w-2xl text-[hsl(var(--paper)/.85)]">Your Chennai → Singapore flight now lands around 13:50 Singapore time instead of 13:10.</p>
        </div>
        <div className="grid gap-6 p-6 md:grid-cols-2 md:p-8">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-[hsl(var(--harbour))]">Why this matters to you</h2>
            <p className="mt-2">Your connection to Sydney (EX212, departs <When iso={run.segments[1].start} />) now has <strong>50 minutes</strong> instead of 90. We use 90 minutes as a planning guide; the airline's real minimum isn't verified. Your connection is <strong>at risk, not confirmed missed</strong>.</p>
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-[hsl(var(--harbour))]">What you should do</h2>
            <ol className="mt-2 space-y-2 text-sm">
              <li className="flex gap-2"><span className="mono font-bold">1</span>Compare the three options below and save the one you prefer.</li>
              <li className="flex gap-2"><span className="mono font-bold">2</span>Ask Example Air staff on arrival or by phone about rebooking. TripGuard can't book for you.</li>
              <li className="flex gap-2"><span className="mono font-bold">3</span>Let the hotel and transfer company know you may arrive late.</li>
            </ol>
          </div>
        </div>
      </section>

      <section aria-labelledby="h-aff" className="in">
        <h2 id="h-aff" className="mb-3 text-xl font-extrabold">Parts of your trip affected</h2>
        <ul className="grid gap-3 md:grid-cols-2">
          {[
            ['EX212 Singapore → Sydney', 'Connection at risk · 50 min left', 'risk' as const],
            ['Harbour View Hotel · HV5520', run.impacts[0].reason, 'risk' as const],
            ['Airport pickup · T9981', `${run.impacts[1].reason} Prepaid AUD 65.00, non-refundable.`, 'risk' as const],
            ['Return flight', 'No return booking found, so nothing to check.', 'ok' as const],
          ].map(([t, r, tone]) => [t, r, tone] as [string, string, 'risk' | 'ok']).map(([t, r, tone]) => (
            <li key={t} className="card p-4">
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${toneCls[tone]}`}>{tone === 'ok' ? 'Not applicable' : 'At risk'}</span>
              <p className="mt-2 font-bold">{t}</p><p className="text-sm text-[hsl(var(--mute))]">{r}</p>
            </li>
          ))}
        </ul>
      </section>

      <section aria-labelledby="h-opt2" className="in space-y-4">
        <div>
          <h2 id="h-opt2" className="text-xl font-extrabold">Options we evaluated</h2>
          <p className="text-sm text-[hsl(var(--mute))]">Suggested: earliest arrival with fewer downstream effects. The cheapest option arrives latest.</p>
        </div>
        <ChosenNote chosen={chosen} onClear={() => setChosen(null)} />
        <Options chosen={chosen} setChosen={setChosen} />
      </section>
      <HowWeGotHere />
    </div>
  );
}

export function TravellerApp({ initial }: { initial: 'home' | 'alert' }) {
  const [view, setView] = useState(initial);
  const [chosen, setChosen] = useState<string | null>(null);
  useEffect(() => { window.scrollTo?.(0, 0); }, [view]);
  return (
    <Shell>
      {view === 'home'
        ? <Home openAlert={() => setView('alert')} chosen={chosen} setChosen={setChosen} />
        : <AlertView back={() => setView('home')} chosen={chosen} setChosen={setChosen} />}
    </Shell>
  );
}
