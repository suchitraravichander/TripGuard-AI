import { TravellerApp } from './_shared';

export default function Home() {
  return <TravellerApp initial="home" />;
}
