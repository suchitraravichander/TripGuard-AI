import { defineConfig, devices } from '@playwright/test';

const baseURL = process.env.TRIPGUARD_E2E_BASE_URL
  ?? (process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : 'http://localhost');
const target = new URL(baseURL);
if (!['localhost', '127.0.0.1'].includes(target.hostname) && !target.hostname.endsWith('.replit.dev')) {
  throw new Error('Browser regressions may only target a local or Replit development preview, never production.');
}

export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  outputDir: '../../generated-artifacts/tripguard-e2e/results',
  reporter: [
    ['list'],
    ['html', { outputFolder: '../../generated-artifacts/tripguard-e2e/report', open: 'never' }],
  ],
  use: {
    baseURL,
    serviceWorkers: 'block',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    launchOptions: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
      ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {},
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 1000 } } },
    { name: 'phone', use: { ...devices['Pixel 7'] } },
  ],
});
