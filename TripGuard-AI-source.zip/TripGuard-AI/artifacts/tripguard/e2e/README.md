# Recovery browser regression

From the workspace root:

```sh
pnpm --filter @workspace/tripguard exec playwright install chromium
pnpm --filter @workspace/tripguard test:e2e
```

Start the existing `artifacts/api-server: API Server` and
`artifacts/tripguard: web` workflows first. The development database must have the
prototype-runs schema applied, and the API background worker must be running.
The suite deliberately waits for its real 8-second delay and server-created alert;
it does not fast-forward timers or mock successful API responses.

The target defaults to `https://$REPLIT_DEV_DOMAIN`, otherwise `http://localhost`
(shared port-80 proxy). Set `TRIPGUARD_E2E_BASE_URL` to another development preview
if needed. Production hosts are rejected. For environments with a system Chromium,
set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` to its executable instead of installing
the bundled browser.

Verified in this workspace with its installed Chromium (six cases passed):

```sh
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/repl/tools/bin/chromium pnpm --filter @workspace/tripguard test:e2e
```

Three scenarios run on both desktop Chromium and a Pixel 7-sized Chromium phone:

1. Sample email → real scheduled delay/alert → recommended choice → reload
   persistence → 95-minute delay → invalidation, including after another reload.
2. HTTP 503 start failure, network-aborted selection, and HTTP 503 delay failure:
   visible errors, unchanged server state, and successful retries.
3. A concurrent real delay update between selection submission and backend
   processing produces a genuine 409. The UI refreshes, accepts a new choice,
   and preserves it after reload.

Each test has a fresh browser context and creates its own synthetic run. No shared
run is reset or deleted. These small synthetic records remain in the development
database for debugging; the suite has no database deletion permission. Browser
requests to external origins and non-prototype writes are blocked. API test calls
only use the synthetic prototype read/delay endpoints. Nothing books travel,
charges money, or sends messages. Phone coverage is viewport/touch emulation,
not a physical device or Safari compatibility claim.

Failures exit nonzero, with no automatic retries to conceal flakes. Reports,
screenshots and traces are in the ignored `generated-artifacts/tripguard-e2e/`
directory. Open the report with:

```sh
pnpm --filter @workspace/tripguard exec playwright show-report ../../generated-artifacts/tripguard-e2e/report
```

List cases without a browser using `pnpm --filter @workspace/tripguard test:e2e:list`.
Check test types using `pnpm --filter @workspace/tripguard typecheck:e2e`.
