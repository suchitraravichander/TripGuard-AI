import { test, expect, type Page, type Route } from '@playwright/test';
import type { PrototypeRun } from '@workspace/api-client-react';

const runs = '/api/prototype/runs';
const choose = (page: Page) => page.locator('[data-testid^="button-choose-"]');

test.beforeEach(async ({ page, baseURL }) => {
  // Fail closed: browser traffic cannot book, send, or call external providers.
  await page.route('**/*', async route => {
    const request = route.request();
    const url = new URL(request.url());
    if (url.origin !== new URL(baseURL!).origin) return route.abort();
    if (!['GET', 'HEAD'].includes(request.method()) &&
        !(request.method() === 'POST' && /^\/api\/prototype\/runs(?:\/[0-9a-f-]{36}\/(?:delay|selection))?$/.test(url.pathname))) {
      throw new Error(`Blocked non-demo write: ${request.method()} ${url.pathname}`);
    }
    await route.continue();
  });
});

async function start(page: Page): Promise<PrototypeRun> {
  await page.goto('/');
  await expect(page.getByTestId('text-email-body')).toContainText('fictional');
  const response = page.waitForResponse(r => new URL(r.url()).pathname === runs && r.request().method() === 'POST');
  await page.getByTestId('button-start-demo').click();
  const created = await response;
  expect(created.status()).toBe(201);
  const run: PrototypeRun = await created.json();
  expect(run.phase).toBe('monitoring');
  expect(run.delayMinutes).toBe(0);
  expect(run.alerts).toEqual([]);
  expect(run.dueAt).not.toBeNull();
  await expect(page.getByTestId('status-phase')).toHaveText('Monitoring');
  await expect(page.locator('[data-testid^="row-segment-"]')).toHaveCount(4);
  return run;
}

async function ready(page: Page, id: string): Promise<PrototypeRun> {
  // Do not inject the happy-path delay: exercise the real background worker and polling.
  await expect(page.getByTestId('status-phase')).toHaveText('Action required', { timeout: 25_000 });
  await expect(page.getByTestId('text-delay')).toHaveText('40 min');
  await expect(page.getByTestId('text-remaining')).toHaveText('50 min');
  const response = await page.request.get(`${runs}/${id}`);
  expect(response.ok()).toBeTruthy();
  const run: PrototypeRun = await response.json();
  expect(run.dueAt).toBeNull();
  expect(run.alerts).toHaveLength(1);
  await expect(page.getByTestId('text-latest-alert')).toHaveText(run.alerts[0]!.text);
  await expect(choose(page)).toHaveCount(3);
  return run;
}

async function setDelay(page: Page, minutes: number) {
  // Native range keyboard interaction works for desktop and emulated phone.
  const slider = page.getByTestId('input-delay');
  await slider.focus();
  await slider.press('Home');
  for (let value = 0; value < minutes; value += 5) await slider.press('ArrowRight');
  await expect(slider).toHaveValue(String(minutes));
}

async function stored(page: Page, id: string): Promise<PrototypeRun> {
  const response = await page.request.get(`${runs}/${id}`);
  expect(response.ok()).toBeTruthy();
  return response.json();
}

async function startReadRecovery(page: Page): Promise<PrototypeRun> {
  await page.goto('/');
  const response = page.waitForResponse(r => new URL(r.url()).pathname === runs && r.request().method() === 'POST');
  await page.getByTestId('button-start-demo').click();
  const created = await response;
  expect(created.status()).toBe(201);
  const run: PrototypeRun = await created.json();
  await expect(page.getByRole('navigation', { name: 'Trip navigation' })).toBeVisible();
  return run;
}

for (const failure of ['network', '503'] as const) {
  for (const stage of ['reload', 'poll'] as const) {
    test(`${failure} read failure during ${stage} preserves the demo and recovers`, async ({ page }) => {
      const run = await startReadRecovery(page);
      const path = `**${runs}/${run.id}`;
      let creates = 0;
      page.on('request', request => {
        if (request.method() === 'POST' && new URL(request.url()).pathname === runs) creates++;
      });
      await page.route(path, route => failure === 'network'
        ? route.abort('failed')
        : route.fulfill({ status: 503, json: { error: 'Synthetic read outage' } }));
      if (stage === 'reload') await page.reload();
      const message = stage === 'reload' ? 'We couldn’t load your demo right now' : 'Showing the last saved assessment; it may be out of date';
      await expect(page.getByRole('alert')).toContainText(message);
      await expect(page.getByRole('alert')).toContainText('Your saved demo ID has been kept');
      await expect(page.getByText('This demo run is no longer available')).toHaveCount(0);
      await expect(page.getByTestId('button-missing-new')).toHaveCount(0);
      expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBe(run.id);
      // Retrying while still unavailable must not discard or replace the saved run.
      await page.getByTestId('button-retry-run').click();
      await expect(page.getByRole('alert')).toContainText(message);
      expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBe(run.id);
      await page.unroute(path);
      // The in-flight retry or next poll can recover immediately; do not race
      // that success by requiring a second click on an already-removed button.
      await expect(page.getByRole('alert')).toHaveCount(0);
      await expect(page.getByRole('navigation', { name: 'Trip navigation' })).toBeVisible();
      expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBe(run.id);
      expect(creates).toBe(0);
      expect((await stored(page, run.id)).id).toBe(run.id);
    });
  }
}

test('a true 404 explains database persistence and allows an explicit new demo', async ({ page }) => {
  const missingId = '00000000-0000-0000-0000-000000000000';
  const response = await page.request.get(`${runs}/${missingId}`);
  expect(response.status()).toBe(404);
  await page.goto('/');
  await page.evaluate(id => localStorage.setItem('tripguard.runId', id), missingId);
  await page.reload();
  await expect(page.getByRole('alert')).toContainText('This demo run is no longer available');
  await expect(page.getByRole('alert')).toContainText('stored in a database');
  await expect(page.getByRole('alert')).not.toContainText('restarted and forgotten');
  expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBe(missingId);
  await page.getByTestId('button-retry-run').click();
  await expect(page.getByRole('alert')).toContainText('This demo run is no longer available');
  await page.getByTestId('button-missing-new').click();
  expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBeNull();
  await expect(page.getByTestId('button-start-demo')).toBeVisible();
  const replacement = await startReadRecovery(page);
  expect(replacement.id).not.toBe(missingId);
});

test('server alert → choose → reload → changed delay invalidates the saved choice', async ({ page }) => {
  const initial = await start(page);
  const run = await ready(page, initial.id);
  const recommended = run.options.find(o => o.recommended)!;
  const button = page.getByTestId(`button-choose-${recommended.id}`);
  await button.click();
  await expect(page.getByTestId('status-phase')).toHaveText('Choice recorded');
  await expect(button).toBeDisabled();
  await expect(page.getByTestId(`card-option-${recommended.id}`)).toContainText('Chosen / not booked');
  expect((await stored(page, run.id)).selectedOptionId).toBe(recommended.id);
  await page.reload();
  await expect(page.getByTestId('status-phase')).toHaveText('Choice recorded');
  await expect(button).toHaveText('Chosen');
  await expect(button).toBeDisabled();
  expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBe(run.id);

  await setDelay(page, 95);
  await page.getByTestId('button-apply-delay').click();
  await expect(page.getByTestId('text-delay')).toHaveText('95 min');
  await expect(page.getByTestId('text-remaining')).toHaveText('-5 min');
  await expect(page.getByTestId('status-phase')).toHaveText('Action required');
  await expect(button).toBeEnabled();
  await expect(page.getByText('Chosen / not booked', { exact: true })).toHaveCount(0);
  expect((await stored(page, run.id)).selectedOptionId).toBeNull();
  await page.reload();
  await expect(page.getByTestId('status-phase')).toHaveText('Action required');
  await expect(button).toBeEnabled();
  await expect(page.getByTestId('text-delay')).toHaveText('95 min');
});

test('failed start, selection and delay requests show errors and permit retry', async ({ page }) => {
  const fail = (route: Route) => route.fulfill({ status: 503, json: { error: 'Synthetic regression outage' } });
  await page.route(`**${runs}`, fail);
  await page.goto('/');
  await page.getByTestId('button-start-demo').click();
  await expect(page.getByRole('alert')).toContainText('Could not start the demo');
  expect(await page.evaluate(() => localStorage.getItem('tripguard.runId'))).toBeNull();
  await page.unroute(`**${runs}`, fail);
  const initial = await start(page);
  const run = await ready(page, initial.id);
  const selectionPath = `**${runs}/${run.id}/selection`;
  await page.route(selectionPath, route => route.abort('failed'));
  await choose(page).first().click();
  await expect(page.getByRole('alert')).toContainText('That choice could not be saved');
  await expect(page.getByTestId('status-phase')).toHaveText('Action required');
  expect((await stored(page, run.id)).selectedOptionId).toBeNull();
  await page.unroute(selectionPath);
  await choose(page).first().click();
  await expect(page.getByTestId('status-phase')).toHaveText('Choice recorded');
  const saved = await stored(page, run.id);

  const delayPath = `**${runs}/${run.id}/delay`;
  await page.route(delayPath, fail);
  await setDelay(page, 95);
  await page.getByTestId('button-apply-delay').click();
  await expect(page.getByRole('alert')).toContainText('Delay could not be applied');
  await expect(page.getByTestId('text-delay')).toHaveText('40 min');
  expect((await stored(page, run.id)).selectedOptionId).toBe(saved.selectedOptionId);
  await page.unroute(delayPath, fail);
  await page.getByTestId('button-apply-delay').click();
  await expect(page.getByTestId('text-delay')).toHaveText('95 min');
  await expect(page.getByRole('alert')).toHaveCount(0);
  expect((await stored(page, run.id)).selectedOptionId).toBeNull();
});

test('a real stale-selection conflict refreshes the assessment before retry', async ({ page }) => {
  const initial = await start(page);
  const run = await ready(page, initial.id);
  const path = `${runs}/${run.id}/selection`;
  // Interleave a real server update after the UI has sent its old version.
  // No mocked 409: the backend's version check must reject this request.
  await page.route(`**${path}`, async route => {
    const pending = route.request().postDataJSON();
    const update = await page.request.post(`${runs}/${run.id}/delay`, { data: { minutes: 95 } });
    expect(update.ok()).toBeTruthy();
    expect((await update.json()).version).toBeGreaterThan(pending.version);
    await route.continue();
  }, { times: 1 });
  const conflict = page.waitForResponse(r => new URL(r.url()).pathname === path);
  await choose(page).first().click();
  expect((await conflict).status()).toBe(409);
  await expect(page.getByRole('alert')).toContainText('That choice could not be saved');
  await expect(page.getByTestId('text-delay')).toHaveText('95 min');
  await expect(page.getByTestId('status-phase')).toHaveText('Action required');
  expect((await stored(page, run.id)).selectedOptionId).toBeNull();
  await choose(page).first().click();
  await expect(page.getByTestId('status-phase')).toHaveText('Choice recorded');
  await expect(page.getByRole('alert')).toHaveCount(0);
  await page.reload();
  await expect(page.getByTestId('status-phase')).toHaveText('Choice recorded');
  await expect(page.getByTestId('text-delay')).toHaveText('95 min');
});
