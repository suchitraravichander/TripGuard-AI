import { useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useSelectPrototypeOption, getGetPrototypeRunQueryKey, type PrototypeRun, type DemoOption } from '@workspace/api-client-react';
import { Check } from 'lucide-react';
import { When } from './traveller-shared';

export function Recovery({ run }: { run: PrototypeRun }) {
  const qc = useQueryClient();
  const mutation = useSelectPrototypeOption();
  const [pending, setPending] = useState<{ option: DemoOption | null; version: number } | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const opener = useRef<HTMLElement | null>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const choice = run.options.find(o=>o.id === run.selectedOptionId);
  const stale = pending !== null && pending.version !== run.version;
  useEffect(()=>{ if (pending) dialog.current?.showModal(); },[pending]);
  const open = (option: DemoOption | null) => {
    opener.current = document.activeElement as HTMLElement;
    mutation.reset(); setPending({option,version:run.version});
  };
  const confirm = () => {
    if (!pending || stale) return;
    mutation.mutate({id:run.id,data:{optionId:pending.option?.id ?? null,version:pending.version}},{
      onSuccess: result => { qc.setQueryData(getGetPrototypeRunQueryKey(run.id),result); dialog.current?.close(); },
      onSettled: ()=>qc.invalidateQueries({queryKey:getGetPrototypeRunQueryKey(run.id)}),
    });
  };
  return <section className="space-y-3" aria-labelledby="recovery-title">
    <h2 ref={heading} tabIndex={-1} id="recovery-title" className="text-lg font-bold">{run.options.length ? `${run.options.length} recovery options, compared` : 'Recovery options'}</h2>
    {run.options.length>0 ? <><p className="text-sm muted">Estimated prices in AUD. Seats and fares are unverified.</p>
      <details className="panel p-4 text-sm"><summary><strong>How we ranked these options</strong></summary><p className="mt-2 muted">Fewer affected bookings first, then earliest arrival, then cost. Demo preferences: budget AUD 500 and arrive before 6 Dec. These are simulated alternatives, not bookable quotes.</p></details></> :
      <div className="panel p-5">{run.delayMinutes===0 ? 'No recovery is needed for the current simulation.' : 'No alternatives are available. Ask the airline for assistance before changing any booking.'}</div>}
    <div aria-live="polite">{choice && <div className="panel border-[hsl(var(--teal))] p-4 text-sm"><p><strong>Preference saved: {choice.title}.</strong> Not booked. Your original bookings and connection risk are unchanged.</p><button className="btn btn-ghost mt-3" onClick={()=>open(null)}>Clear preference</button></div>}</div>
    <div className="grid gap-3 lg:grid-cols-3">{[...run.options].sort((a,b)=>Number(b.recommended)-Number(a.recommended)).map(o=>{
      const selected=run.selectedOptionId===o.id;
      return <article key={o.id} data-testid={`card-option-${o.id}`} className={`panel flex flex-col p-4 ${selected?'ring-2 ring-[hsl(var(--teal))]':''}`}>
        <div className="flex min-h-6 flex-wrap gap-1">{o.recommended && <span className="chip chip-teal">Recommended</span>}{selected && <span className="chip chip-sand"><Check className="h-3 w-3" aria-hidden/>Saved · not booked</span>}</div>
        <h3 className="my-3 font-semibold">{o.title}</h3><dl className="space-y-3 text-sm">
          <div className="flex justify-between gap-2"><dt className="muted">Arrive Sydney</dt><dd className="text-right"><When iso={o.arrival}/></dd></div>
          <div className="flex justify-between gap-2"><dt className="muted">Estimated cost</dt><dd className="mono">{o.currency} {o.cost.toFixed(2)}</dd></div>
          <div className="flex justify-between gap-2"><dt className="muted">Later bookings affected</dt><dd>{o.reason.match(/(\d+) downstream booking/)?.[1] ?? 'Unconfirmed'}</dd></div>
          <div className="flex justify-between gap-2"><dt className="muted">Availability</dt><dd>Unverified</dd></div>
        </dl><details className="my-3 text-xs muted"><summary>Why this option</summary><p className="mt-2">{o.reason}</p></details><button data-testid={`button-choose-${o.id}`} disabled={selected} onClick={()=>open(o)} className="btn btn-ghost mt-auto justify-center pt-3">{selected?'Your preference':choice?'Change to this':'Prefer this option'}</button>
      </article>;
    })}</div>
    <dialog ref={dialog} aria-labelledby="confirm-heading" onCancel={e=>{if(mutation.isPending)e.preventDefault();}} onClose={()=>{setPending(null);(opener.current?.isConnected ? opener.current : heading.current)?.focus();}} className="m-auto w-[min(92vw,460px)] rounded-2xl border p-0 text-[hsl(var(--ink))]">
      {pending && <div className="bg-[hsl(var(--surface))] p-6"><h2 id="confirm-heading" className="text-xl font-bold">{pending.option?'Save this recovery preference?':'Clear your recovery preference?'}</h2>
        {pending.option && <p className="mt-3">{pending.option.title} · {pending.option.currency} {pending.option.cost.toFixed(2)} estimated</p>}
        <p className="my-4 text-sm muted">This updates your saved trip preference only. Nothing is booked, paid or sent to an airline. Connection risk remains unchanged.</p>
        {stale && <p role="alert" className="mb-3 text-sm text-[hsl(var(--coral))]">The assessment changed while this was open. Close and review the latest options.</p>}
        {mutation.isError && <p role="alert" className="mb-3 text-sm text-[hsl(var(--coral))]">Could not save. The trip may have changed or the service is unavailable. Your previous preference is unchanged; close and review before retrying.</p>}
        <div className="flex flex-wrap justify-end gap-2"><button autoFocus className="btn btn-ghost" disabled={mutation.isPending} onClick={()=>dialog.current?.close()}>Cancel</button><button className="btn btn-primary" disabled={stale || mutation.isPending} onClick={confirm}>{mutation.isPending?'Saving…':pending.option?'Save preference':'Clear preference'}</button></div>
      </div>}
    </dialog>
  </section>;
}
