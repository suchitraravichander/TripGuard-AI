import { ChevronDown, Plane, BedDouble, Car } from 'lucide-react';
import type { DemoSegment, PrototypeRun } from '@workspace/api-client-react';

export function When({ iso }: { iso: string | null }) {
  if (!iso) return <span>Not stated</span>;
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}).*?(Z|[+-]\d{2}:\d{2})$/);
  if (!m) return <span>{iso}</span>;
  const zones: Record<string, string> = { '+05:30': 'IST', '+08:00': 'SGT', '+11:00': 'AEDT', Z: 'UTC' };
  return <time dateTime={iso}><span className="mono font-medium">{m[4]}:{m[5]}</span> <span className="muted">{Number(m[3])} {['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][Number(m[2])-1]} {zones[m[6]] ?? `UTC${m[6]}`}</span></time>;
}
export function shiftedArrival(s: DemoSegment, minutes: number) {
  if (!s.end) return null;
  const shifted = new Date(Date.parse(s.end.slice(0, 19) + 'Z') + minutes * 60_000);
  return shifted.toISOString().slice(0, 19) + s.end.slice(19);
}
export function Activity({ run }: { run: PrototypeRun }) {
  const changed = run.delayMinutes > 0;
  const steps = ['Monitoring your flight', ...(changed ? ['Detected schedule change', 'Analysed connection', ...(run.options.length ? ['Checked alternatives', `Found ${run.options.length} recovery options`] : ['No verified recovery options available'])] : ['No current delay reported'])];
  return <details className="panel text-sm"><summary className="flex items-center justify-between px-4 py-3 font-medium">How TripGuard got here <ChevronDown className="h-4 w-4" aria-hidden /></summary><ol className="space-y-2 border-t px-4 py-3">{steps.map((s,i)=><li key={s} className="flex gap-2"><span className="mono muted">{i+1}.</span>{s}</li>)}</ol></details>;
}
export function Timeline({ run }: { run: PrototypeRun }) {
  return <section className="panel p-4"><h2 className="label mb-4">Trip timeline</h2><ol>{run.segments.map((s,i)=>{
    const Icon = s.type === 'hotel' ? BedDouble : s.type.includes('transfer') ? Car : Plane;
    const impact = run.impacts.find(im=>im.segmentId === s.id);
    const status = i===0 && run.delayMinutes>0 ? `Delayed ${run.delayMinutes} min` : i===1 && run.delayMinutes>0 ? 'Connection at risk' : impact ? 'May be affected' : 'Scheduled';
    return <li key={s.id} className="flex gap-3 pb-4"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--teal-soft))] text-[hsl(var(--teal))]"><Icon className="h-4 w-4" aria-hidden /></span>
      <details className="min-w-0 flex-1"><summary><span className="flex flex-wrap justify-between gap-2"><strong>{s.type==='flight' ? `${s.service} ${s.origin} → ${s.destination}` : s.provider}</strong><span className={`chip ${status==='Scheduled'?'chip-teal':'chip-coral'}`}>{status}</span></span><span className="mt-1 block text-sm"><When iso={s.start}/>{s.end && <> → <When iso={i===0 ? shiftedArrival(s,run.delayMinutes) : s.end}/></>}</span><span className="mt-1 flex items-center gap-1 text-xs muted">Booking details <ChevronDown className="h-3 w-3" aria-hidden /></span></summary>
        <div className="mt-2 space-y-1 text-sm muted"><p>Booking {s.bookingId.split(':').at(-1)} · {s.provider}</p>{i===0 && run.delayMinutes>0 && <p>Estimated arrival above; scheduled arrival <When iso={s.end}/>.</p>}{impact && <p>{impact.reason}</p>}{i===1 && <p>Airline minimum connection time is unverified.</p>}</div>
      </details></li>;
  })}</ol><p className="border-t pt-3 text-xs muted">No return booking was included in this sample.</p></section>;
}
