import { useEffect, useRef, useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { useCreatePrototypeRun, useGetPrototypeRun, useGetPrototypeSample, getGetPrototypeRunQueryKey, type PrototypeRun } from '@workspace/api-client-react';
import { ArrowLeft, ArrowRight, Bell, Plane, RotateCcw, ShieldCheck } from 'lucide-react';
import { Activity, Timeline, When, shiftedArrival } from '@/components/traveller-shared';
import { Recovery } from '@/components/traveller-recovery';
import { DelayControl, EmailCard, ItineraryJson, RunReadError } from './guardian';
import '../traveller.css';

const RUN_KEY='tripguard.runId';
function storedRun() { try { return localStorage.getItem(RUN_KEY); } catch { return null; } }

export default function Traveller() {
  const [location,navigate]=useLocation();
  const [runId,setRunId]=useState<string|null>(()=>new URLSearchParams(window.location.search).get('trip') || storedRun());
  const qc=useQueryClient();
  const sample=useGetPrototypeSample();
  const create=useCreatePrototypeRun();
  const run=useGetPrototypeRun(runId??'',{query:{enabled:!!runId,queryKey:getGetPrototypeRunQueryKey(runId??''),refetchInterval:1500,retry:1}});
  const alerts=location==='/alerts';
  useEffect(()=>{document.title=alerts?'TripGuard · Alerts & recovery':'TripGuard · My trip';window.scrollTo(0,0);},[alerts]);
  const start=()=>create.mutate(undefined,{onSuccess:r=>{
    try {localStorage.setItem(RUN_KEY,r.id);}catch{/* The URL also preserves this synthetic demo. */}
    qc.setQueryData(getGetPrototypeRunQueryKey(r.id),r);setRunId(r.id);navigate(`/?trip=${r.id}`);
  }});
  const reset=()=>{try{localStorage.removeItem(RUN_KEY);}catch{}setRunId(null);create.reset();navigate('/');};
  const href=(page:string)=>`${page}${runId?`?trip=${encodeURIComponent(runId)}`:''}`;
  const notFound = run.isError && run.error?.status===404;
  const unavailable = run.isError && (!run.data || notFound);
  return <div className="rf">
    <header className="border-b border-[hsl(var(--line))] bg-[hsl(var(--surface))]"><div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 md:px-6">
      <Link href={href('/')} className="flex items-center gap-2 font-bold text-lg"><ShieldCheck className="h-6 w-6 text-[hsl(var(--teal))]" aria-hidden/>TripGuard<span className="text-[hsl(var(--teal))]">AI</span></Link>
      <div className="flex items-center gap-2"><span className="chip chip-line">Simulation</span>{runId && <button data-testid="button-new-demo" onClick={reset} className="btn btn-ghost"><RotateCcw className="h-4 w-4" aria-hidden/><span>New demo</span></button>}</div>
    </div></header>
    <main className="mx-auto max-w-6xl space-y-5 px-4 py-6 md:px-6">
      {runId && <nav aria-label="Trip navigation" className="flex gap-2"><Link aria-current={!alerts?'page':undefined} className={`btn ${!alerts?'btn-primary':'btn-ghost'}`} href={href('/')}><Plane className="h-4 w-4" aria-hidden/>My trip</Link><Link aria-current={alerts?'page':undefined} className={`btn ${alerts?'btn-primary':'btn-ghost'}`} href={href('/alerts')}><Bell className="h-4 w-4" aria-hidden/>Alerts & recovery{run.data?.alerts.length ? <span className="rounded-full border px-1.5 text-xs">{run.data.alerts.length}</span>:null}</Link></nav>}
      {!runId ? <section className="panel mx-auto max-w-3xl overflow-hidden"><div className="route-banner p-6 md:p-8"><p className="label text-inherit">YOUR JOURNEY, LOOKED AFTER</p><h1 className="mt-3 text-3xl font-bold">A clearer next step.<br/>Even when plans change.</h1><div className="my-7 flex items-center justify-between gap-2 font-semibold"><span>Chennai<br/><strong className="mono text-2xl">MAA</strong></span><Plane aria-hidden/><span>Singapore<br/><strong className="mono text-2xl">SIN</strong></span><Plane aria-hidden/><span>Sydney<br/><strong className="mono text-2xl">SYD</strong></span></div></div>
        <div className="space-y-4 p-6"><h2 className="text-xl font-bold">Try your travel guardian</h2><p className="muted">Start with a fictional booking email. We’ll save the trip, simulate a flight delay after eight seconds, explain its impact and compare your recovery options.</p>
          <button data-testid="button-start-demo" disabled={create.isPending || !sample.data} onClick={start} className="btn btn-primary">{create.isPending?'Preparing your trip…':'Start guarding this trip'}<ArrowRight className="h-4 w-4" aria-hidden/></button>
          {create.isError && <p role="alert">Could not create your trip. Please try again.</p>}
          <details><summary className="text-sm font-semibold">View the sample booking email</summary><div className="mt-3"><EmailCard {...sample.data} loading={sample.isLoading} error={sample.isError} onRetry={()=>sample.refetch()}/></div></details>
          {sample.isError && <button className="btn btn-ghost" onClick={()=>sample.refetch()}>Retry loading sample</button>}
        </div></section> : unavailable ? <RunReadError missing={notFound} onRetry={()=>run.refetch()} onNew={reset}/> :
      !run.data ? <div className="panel p-8" role="status">Loading your trip…</div> : <>
        {run.isError && <p role="alert" className="panel p-3 text-sm">Updates are unavailable. Showing the last saved assessment; it may be out of date. Your saved demo ID has been kept. <button data-testid="button-retry-run" className="underline" onClick={()=>run.refetch()}>Retry</button></p>}
        <div className="sr-only" aria-live="polite">{run.data.alerts.at(-1)?.text}</div>
        {alerts ? <AlertPage run={run.data} home={href('/')}/> : <Home run={run.data} alertHref={href('/alerts')}/>}
        <details className="panel"><summary className="px-4 py-3 text-sm font-semibold">Demo controls & source data</summary><div className="grid gap-4 border-t p-4 md:grid-cols-2"><DelayControl run={run.data}/><div className="space-y-3"><EmailCard {...sample.data} loading={sample.isLoading} error={sample.isError} onRetry={()=>sample.refetch()}/><ItineraryJson json={run.data.itineraryJson}/></div></div></details>
      </>}
    </main><footer className="mx-auto max-w-6xl px-5 pb-8 pt-4 text-center text-xs muted">Fictional travel data · In-app alerts only · Nothing is booked or sent externally</footer>
  </div>;
}

function Home({run,alertHref}:{run:PrototypeRun;alertHref:string}) {
  const changed=run.delayMinutes>0;
  const first=run.segments.find(s=>s.type==='flight');
  const onward=run.segments.filter(s=>s.type==='flight')[1];
  const choice=run.options.find(o=>o.id===run.selectedOptionId);
  return <>
    <div><p className="label">MY TRIP · 4–6 DEC 2026</p><h1 className="mt-1 text-2xl font-bold">Chennai to Sydney</h1><p className="text-sm muted">Via Singapore · {run.segments.length} connected bookings</p></div>
    <div className="grid items-start gap-5 lg:grid-cols-[1fr_1.15fr]">
      <div className="space-y-4">
        <section className="panel overflow-hidden"><div className={`border-l-4 p-5 ${changed?'border-[hsl(var(--coral))]':'border-[hsl(var(--teal))]'}`}><div className="flex justify-between gap-2"><h2 className="label">{changed?'Important alert':'Trip status'}</h2><span data-testid="status-risk" className={`chip ${changed?'chip-coral':'chip-teal'}`}>{run.riskLevel} risk</span></div><h3 className="mt-2 text-xl font-bold">{changed?'Your connection needs attention':'Watching over your journey'}</h3><p className="mt-2 muted">{changed?`${first?.service??'Your first flight'} is ${run.delayMinutes} minutes late. ${Math.max(0,run.remainingMinutes)} minutes remain before your onward departure.`:'No current delay in this simulation. Your itinerary is saved and monitoring is active.'}</p>{changed && <p className="mt-2 text-sm">{run.remainingMinutes>0?'At risk, not confirmed missed.':'Predicted arrival is at or after the onward departure.'} Airline rules are unverified.</p>}<p className="mt-3 text-sm">{changed?<><span className="chip chip-sand">Review now</span> Airline deadline unknown.</>:run.dueAt?'A simulated delay will arrive shortly.':'We’ll show any new alerts here.'}</p><Link href={alertHref} className="btn btn-primary mt-4">{changed?'See what to do':'View trip updates'}<ArrowRight className="h-4 w-4" aria-hidden/></Link></div></section>
        {choice && <div className="panel p-4 text-sm"><CheckNote title={choice.title}/><Link href={alertHref} className="mt-2 inline-block underline">Review or change preference</Link></div>}
        {first && <section className="panel overflow-hidden"><div className="route-banner p-4"><div className="flex items-center justify-between text-sm"><span>{first.provider} · {first.service}</span><span className="chip chip-line">{changed?`+${run.delayMinutes} min`:'Scheduled'}</span></div><div className="mt-5 flex items-center justify-between gap-2"><div><h2 className="mono text-3xl font-semibold">{first.origin}</h2><When iso={first.start}/></div><Plane className="h-5 w-5 shrink-0" aria-hidden/><div className="text-right"><h2 className="mono text-3xl font-semibold">{first.destination}</h2><When iso={shiftedArrival(first,run.delayMinutes)}/></div></div></div><p className="p-4 text-xs muted">{changed?'Estimated arrival shown. ':'Scheduled times shown. '}{onward && <>Next flight: {onward.service} at <When iso={onward.start}/></>}</p></section>}
        <Activity run={run}/>
      </div>
      <div className="space-y-4"><Timeline run={run}/><section className="panel p-4"><h2 className="label mb-3">Upcoming bookings · scheduled</h2><ul className="space-y-3 text-sm">{run.segments.slice(1).map(s=><li key={s.id} className="flex flex-wrap justify-between gap-2"><span>{s.service??s.provider}</span><When iso={s.start}/></li>)}</ul></section></div>
    </div>
  </>;
}
function CheckNote({title}:{title:string}){return <p><strong>Preference saved: {title}.</strong> Not booked; your original itinerary and risk remain unchanged.</p>;}
function AlertPage({run,home}:{run:PrototypeRun;home:string}){
  const heading=useRef<HTMLHeadingElement>(null);
  useEffect(()=>{heading.current?.focus();},[]);
  const changed=run.delayMinutes>0;
  const flights=run.segments.filter(s=>s.type==='flight');
  const inbound=flights[0];
  const onward=flights[1];
  return <div className="space-y-5"><Link href={home} className="btn btn-ghost"><ArrowLeft className="h-4 w-4" aria-hidden/>Back to my trip</Link><section className="panel border-l-4 border-l-[hsl(var(--coral))] p-5"><span className={`chip ${changed?'chip-coral':'chip-teal'}`}>{run.riskLevel} risk</span><h1 ref={heading} tabIndex={-1} className="my-3 text-2xl font-bold">{changed?`Flight delayed ${run.delayMinutes} minutes`:'No current disruption'}</h1><dl className="grid gap-4 text-sm md:grid-cols-2"><div><dt className="label">What happened?</dt><dd>{changed && inbound ? <>{inbound.service} now lands at <When iso={shiftedArrival(inbound,run.delayMinutes)}/> instead of <When iso={inbound.end}/>. This is a simulated delay.</>:'The saved itinerary has no simulated delay.'}</dd></div><div><dt className="label">Why it matters to you</dt><dd>{changed ? <>{onward?.service??'Your next flight'} departs <When iso={onward?.start??null}/>. {run.remainingMinutes>0 ? `${run.remainingMinutes} minutes remain to connect, instead of 90. The connection is at risk, not confirmed missed.` : 'Your inbound arrival is predicted at or after departure.'} The 90-minute planning guide is not a verified airline minimum.</> : 'Your connection has its scheduled 90-minute window.'}</dd></div><div><dt className="label">How urgent is it?</dt><dd>{changed?'Review now. The airline’s rebooking deadline is unknown.':'No action required for this simulation.'}</dd></div><div><dt className="label">What should I do?</dt><dd>{changed?'Compare the alternatives below and confirm availability with the airline before changing bookings. Ask the hotel and pickup provider about late arrival.':'We’ll show an alert when something changes.'} TripGuard cannot book for you.</dd></div></dl></section>
    {run.impacts.length>0 && <section><h2 className="mb-3 text-lg font-bold">Parts of your trip affected</h2><div className="grid gap-3 md:grid-cols-2">{run.impacts.map(im=><article key={im.segmentId} className="panel p-4"><span className="chip chip-coral">{im.classification.replaceAll('_',' ')}</span><h3 className="my-2 font-semibold">{run.segments.find(s=>s.id===im.segmentId)?.provider??im.segmentId}</h3><p className="text-sm muted">{im.reason}</p><p className="mt-2 text-xs">{im.amount===null?'Cost exposure unknown':`${im.currency} ${im.amount.toFixed(2)} potentially exposed; not confirmed lost`}</p></article>)}</div></section>}
    <Recovery run={run}/><Activity run={run}/>
    {run.alerts.length>0 && <details className="panel p-4"><summary className="text-sm font-semibold">Previous alerts ({run.alerts.length})</summary><ol className="mt-3 space-y-3">{[...run.alerts].reverse().map(a=><li key={a.id} className="border-t pt-3 text-sm"><p className="mb-1 text-xs muted">Generated <When iso={a.createdAt}/> · {a.level}</p>{a.text}</li>)}</ol></details>}
  </div>;
}
