import { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  useGetPrototypeSample,
  useCreatePrototypeRun,
  useGetPrototypeRun,
  useSimulatePrototypeDelay,
  useSimulatePrototypeEvent,
  useSelectPrototypeOption,
  getGetPrototypeSampleQueryKey,
  getGetPrototypeRunQueryKey,
} from '@workspace/api-client-react';
import type { PrototypeRun, DemoOption, SampleEmail } from '@workspace/api-client-react';
import {
  AlertTriangle,
  ArrowRight,
  Check,
  ChevronDown,
  Clock,
  Mail,
  Plane,
  RotateCcw,
  ShieldCheck,
  Train,
  BedDouble,
  Radio,
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const RUN_KEY = 'tripguard.runId';

/* ---------- time: never use browser local zone ---------- */
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function parseIso(iso: string | null | undefined) {
  if (!iso) return null;
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::\d{2}(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?/);
  if (!m) return null;
  const off = !m[6] ? 'zone unstated' : m[6] === 'Z' ? 'UTC' : `UTC${m[6]}`;
  return { time: `${m[4]}:${m[5]}`, date: `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]}`, off };
}
function T({ iso, className = '' }: { iso: string | null | undefined; className?: string }) {
  const p = parseIso(iso);
  if (!p) return <span className={className}>{iso ?? 'unknown'}</span>;
  return (
    <time dateTime={iso!} className={`font-mono ${className}`}>
      {p.time} <span className="opacity-70">{p.date}</span>{' '}
      <span className="text-[0.7em] opacity-60">{p.off}</span>
    </time>
  );
}
function money(n: number | null | undefined, cur?: string | null) {
  if (n === null || n === undefined) return 'Unknown';
  return `${cur ?? ''} ${n.toFixed(2)}`.trim();
}

const RISK: Record<string, { label: string; cls: string }> = {
  low: { label: 'Low', cls: 'bg-[hsl(var(--safe))] text-primary-foreground' },
  medium: { label: 'Medium', cls: 'bg-accent text-accent-foreground' },
  high: { label: 'High', cls: 'bg-destructive text-destructive-foreground' },
  critical: { label: 'Critical', cls: 'bg-destructive text-destructive-foreground' },
};
function riskStyle(r: string) {
  return RISK[r.toLowerCase()] ?? { label: r, cls: 'bg-secondary text-secondary-foreground' };
}

function segIcon(type: string) {
  const t = type.toLowerCase();
  if (t.includes('train') || t.includes('rail')) return Train;
  if (t.includes('hotel') || t.includes('stay')) return BedDouble;
  return Plane;
}

/* ---------- page ---------- */
export default function Guardian() {
  const qc = useQueryClient();
  const [runId, setRunId] = useState<string | null>(() => localStorage.getItem(RUN_KEY));
  const sample = useGetPrototypeSample();
  const create = useCreatePrototypeRun();
  const run = useGetPrototypeRun(runId ?? '', {
    query: { enabled: !!runId, queryKey: getGetPrototypeRunQueryKey(runId ?? ''), refetchInterval: 1500, retry: 1 },
  });

  const start = () =>
    create.mutate(undefined, {
      onSuccess: (r) => {
        localStorage.setItem(RUN_KEY, r.id);
        qc.setQueryData(getGetPrototypeRunQueryKey(r.id), r);
        setRunId(r.id);
      },
    });
  const reset = () => {
    localStorage.removeItem(RUN_KEY);
    setRunId(null);
    create.reset();
  };

  return (
    <div className="min-h-[100dvh]">
      <header className="border-b border-border bg-primary text-primary-foreground">
        <div className="hazard h-1.5" aria-hidden />
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 md:px-8">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-sm bg-accent text-accent-foreground">
              <ShieldCheck className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <h1 className="text-xl font-extrabold leading-none tracking-tight">TripGuard AI</h1>
              <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.2em] opacity-70">Connection guardian / prototype</p>
            </div>
          </div>
          {runId && (
            <button
              data-testid="button-new-demo"
              onClick={reset}
              className="inline-flex items-center gap-2 rounded-sm border border-primary-foreground/30 px-3 py-2 text-sm font-semibold hover:bg-primary-foreground/10 focus-visible:outline-2 focus-visible:outline-accent"
            >
              <RotateCcw className="h-4 w-4" aria-hidden /> Start new demo
            </button>
          )}
        </div>
      </header>

      <Constraints />

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-8 md:px-8">
        {!runId ? (
          <StartView sample={sample} onStart={start} pending={create.isPending} error={create.isError} />
        ) : run.isLoading ? (
          <RunSkeleton />
        ) : run.isError || !run.data ? (
          <RunReadError missing={run.error?.status === 404} onRetry={() => run.refetch()} onNew={reset} />
        ) : (
          <RunView run={run.data} sampleBody={sample.data?.body} sampleSubject={sample.data?.subject} sampleFrom={sample.data?.from} />
        )}
      </main>
      <footer className="border-t border-border py-6 text-center font-mono text-xs text-muted-foreground">
        Synthetic data only. No bookings, purchases or messages are ever sent.
      </footer>
    </div>
  );
}

function Constraints() {
  return (
    <div className="border-b border-border bg-secondary/60" data-testid="text-constraints">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-1 px-4 py-2 font-mono text-xs md:px-8">
        <span className="uppercase tracking-widest text-muted-foreground">Demo constraints</span>
        <span>Budget <strong>AUD 500.00</strong></span>
        <span>Arrive <strong>before 6 Dec</strong></span>
        <span className="text-muted-foreground">Assumed for this prototype</span>
      </div>
    </div>
  );
}

/* ---------- start ---------- */
export function EmailCard({ subject, from, body, loading, error, onRetry }: { subject?: string; from?: string; body?: string; loading?: boolean; error?: boolean; onRetry?: () => void }) {
  return (
    <article className="overflow-hidden rounded-md border border-card-border bg-card shadow-[0_1px_0_hsl(var(--border)),0_12px_30px_-18px_hsl(222_48%_17%/0.35)]" aria-label="Sample booking email (read-only)">
      <div className="flex items-center justify-between border-b border-border bg-muted/60 px-4 py-2">
        <span className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-muted-foreground">
          <Mail className="h-3.5 w-3.5" aria-hidden /> Sample email / read-only
        </span>
        <span className="font-mono text-[10px] uppercase text-muted-foreground">fictional</span>
      </div>
      {loading ? (
        <div className="space-y-2 p-4">
          <Skeleton className="h-5 w-2/3" /><Skeleton className="h-4 w-1/3" /><Skeleton className="h-40 w-full" />
        </div>
      ) : error ? (
        <div className="p-6 text-sm">
          <p>The sample email could not be loaded.</p>
          <button data-testid="button-retry-sample" onClick={onRetry} className="mt-3 underline underline-offset-4">Try again</button>
        </div>
      ) : (
        <div className="p-4">
          <h3 className="text-lg font-semibold leading-snug" data-testid="text-email-subject">{subject}</h3>
          <p className="mt-1 font-mono text-xs text-muted-foreground">From: {from}</p>
          <pre className="mt-4 max-h-80 overflow-auto whitespace-pre-wrap font-mono text-[12.5px] leading-relaxed text-foreground/85" data-testid="text-email-body">{body}</pre>
        </div>
      )}
    </article>
  );
}

function StartView({ sample, onStart, pending, error }: { sample: { data?: SampleEmail; isLoading: boolean; isError: boolean; refetch: () => unknown }; onStart: () => void; pending: boolean; error: boolean }) {
  return (
    <div className="grid gap-10 md:grid-cols-[1fr_1.1fr] md:items-start">
      <section className="rise">
        <p className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">Step 01 / Read the booking</p>
        <h2 className="mt-3 text-4xl font-extrabold leading-[1.02] tracking-tight md:text-5xl">
          One late flight.<br />Every connection after it, <span className="bg-accent px-1">checked</span>.
        </h2>
        <p className="mt-5 max-w-md text-muted-foreground">
          TripGuard reads this fictional booking email, builds your itinerary, then watches it. Try simulated delays, cancellations and official-weather-warning fixtures. Forecasts are not cancellations. You choose; nothing is booked.
        </p>
        <ol className="mt-6 space-y-2 font-mono text-sm">
          <li>01 Extract itinerary from email</li>
          <li>02 Monitor. A 40 min delay arrives on its own after ~8 s</li>
          <li>03 Review risk, impacts and options</li>
        </ol>
        <button
          data-testid="button-start-demo"
          onClick={onStart}
          disabled={pending || !sample.data}
          className="mt-8 inline-flex items-center gap-3 rounded-sm bg-primary px-6 py-4 text-base font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:opacity-60"
        >
          {pending ? 'Reading email...' : 'Start guarding this trip'} <ArrowRight className="h-5 w-5" aria-hidden />
        </button>
        {error && <p role="alert" className="mt-3 text-sm text-destructive">Could not start the demo. Please try again.</p>}
      </section>
      <div className="rise" style={{ animationDelay: '120ms' }}>
        <EmailCard subject={sample.data?.subject} from={sample.data?.from} body={sample.data?.body} loading={sample.isLoading} error={sample.isError} onRetry={() => sample.refetch()} />
      </div>
    </div>
  );
}

function RunSkeleton() {
  return (
    <div className="grid gap-6 md:grid-cols-3" aria-busy="true" aria-label="Loading trip">
      <Skeleton className="h-40 md:col-span-3" />
      <Skeleton className="h-72 md:col-span-2" />
      <Skeleton className="h-72" />
    </div>
  );
}

export function RunReadError({ missing, onRetry, onNew }: { missing: boolean; onRetry: () => void; onNew: () => void }) {
  return (
    <div className="mx-auto max-w-lg rounded-md border border-dashed border-border bg-card p-8 text-center" role="alert">
      <AlertTriangle className="mx-auto h-8 w-8 text-destructive" aria-hidden />
      <h2 className="mt-3 text-2xl font-bold">{missing ? 'This demo run is no longer available' : 'We couldn’t load your demo right now'}</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        {missing
          ? 'No demo was found for this saved ID. Prototype runs are stored in a database, not just server memory. You can retry or start a new demo.'
          : 'There may be a temporary connection or server problem. Your saved demo ID has been kept. Retry to load the same demo when the connection is restored.'}
      </p>
      <div className="mt-6 flex justify-center gap-3">
        <button data-testid="button-retry-run" onClick={onRetry} className="rounded-sm border border-border px-4 py-2 text-sm font-semibold hover:bg-muted">Retry</button>
        {missing && <button data-testid="button-missing-new" onClick={onNew} className="rounded-sm bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Start new demo</button>}
      </div>
    </div>
  );
}

/* ---------- run ---------- */
function RunView({ run, sampleBody, sampleSubject, sampleFrom }: { run: PrototypeRun; sampleBody?: string; sampleSubject?: string; sampleFrom?: string }) {
  const latest = run.alerts.length ? run.alerts[run.alerts.length - 1] : null;
  const monitoring = run.phase === 'monitoring';
  return (
    <div className="space-y-8">
      <StatusBoard run={run} />

      <div aria-live="assertive" aria-atomic="true" data-testid="region-latest-alert">
        {latest && (
          <div key={latest.id} className="rise flex gap-4 rounded-md border-2 border-primary bg-accent p-5 text-accent-foreground">
            <Radio className="mt-0.5 h-6 w-6 shrink-0" aria-hidden />
            <div>
              <p className="font-mono text-xs uppercase tracking-widest">In-app alert / {latest.level} / <T iso={latest.createdAt} /></p>
              <p className="mt-1 text-lg font-semibold leading-snug" data-testid="text-latest-alert">{latest.text}</p>
            </div>
          </div>
        )}
      </div>

      <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-8">
          <Timeline run={run} />
          {!monitoring && <Impacts run={run} />}
          {!monitoring ? <Options run={run} /> : <Watching />}
        </div>
        <aside className="space-y-6">
          <DelayControl run={run} />
          <AlertLog run={run} />
          <Activity run={run} />
          <details className="group rounded-md border border-border bg-card">
            <summary data-testid="button-toggle-email" className="flex cursor-pointer items-center justify-between px-4 py-3 text-sm font-semibold">
              Source email <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" aria-hidden />
            </summary>
            <div className="border-t border-border p-2">
              <EmailCard subject={sampleSubject} from={sampleFrom} body={sampleBody} loading={!sampleBody} />
            </div>
          </details>
          <ItineraryJson json={run.itineraryJson} />
        </aside>
      </div>
    </div>
  );
}

function StatusBoard({ run }: { run: PrototypeRun }) {
  const r = riskStyle(run.riskLevel);
  const phaseLabel = run.phase === 'monitoring' ? 'Monitoring' : run.phase === 'action_required' ? 'Action required' : 'Choice recorded';
  return (
    <section className="rise overflow-hidden rounded-md bg-primary text-primary-foreground" aria-label="Trip status">
      <div className="grid divide-y divide-primary-foreground/15 md:grid-cols-4 md:divide-x md:divide-y-0">
        <Cell label="Status">
          <span className="inline-flex items-center gap-2">
            {run.phase === 'monitoring' && <span className="pulse-dot h-2.5 w-2.5 rounded-full bg-accent" aria-hidden />}
            <span key={run.phase} className="flap" data-testid="status-phase">{phaseLabel}</span>
          </span>
        </Cell>
        <Cell label="Simulated flight status">
          <span key={run.event ?? run.delayMinutes} className="flap font-mono" data-testid="text-delay">{run.event === 'cancellation' ? 'Cancelled' : `${run.delayMinutes} min delay`}</span>
        </Cell>
        <Cell label="Connection time left">
          <span key={run.remainingMinutes} className={`flap font-mono ${run.remainingMinutes !== null && run.remainingMinutes < 0 ? 'text-accent' : ''}`} data-testid="text-remaining">
            {run.remainingMinutes === null ? 'Not applicable' : `${run.remainingMinutes} min`}
          </span>
        </Cell>
        <Cell label="Risk">
          <span key={run.riskLevel} className={`flap rounded-sm px-2 py-0.5 font-mono text-base uppercase ${r.cls}`} data-testid="status-risk">{r.label}</span>
        </Cell>
      </div>
      <p className="border-t border-primary-foreground/15 px-5 py-4 text-sm leading-relaxed text-primary-foreground/85" data-testid="text-reasoning">
        <span className="font-mono text-xs uppercase tracking-widest text-accent">Why </span>{run.reasoning}
      </p>
    </section>
  );
}
function Cell({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="px-5 py-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground/60">{label}</p>
      <div className="mt-1.5 text-2xl font-bold" style={{ perspective: 400 }}>{children}</div>
    </div>
  );
}

function SectionTitle({ n, children }: { n: string; children: React.ReactNode }) {
  return (
    <h2 className="mb-4 flex items-baseline gap-3 text-2xl font-extrabold tracking-tight">
      <span className="font-mono text-sm text-muted-foreground">{n}</span>{children}
    </h2>
  );
}

function Timeline({ run }: { run: PrototypeRun }) {
  const impactFor = (id: string) => run.impacts.find((i) => i.segmentId === id);
  return (
    <section aria-labelledby="h-itin">
      <SectionTitle n="01"><span id="h-itin">Your connected journey</span></SectionTitle>
      <ol className="relative space-y-3 before:absolute before:bottom-4 before:left-[19px] before:top-4 before:w-px before:bg-border">
        {run.segments.map((s, i) => {
          const Icon = segIcon(s.type);
          const imp = impactFor(s.id);
          const hit = imp && !/ok|safe|unaffected|none/i.test(imp.classification);
          return (
            <li key={s.id} className="rise relative flex gap-4" style={{ animationDelay: `${i * 70}ms` }} data-testid={`row-segment-${s.id}`}>
              <span className={`relative z-10 grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 ${hit ? 'border-destructive bg-destructive text-destructive-foreground' : 'border-primary bg-card'}`}>
                <Icon className="h-4 w-4" aria-hidden />
              </span>
              <div className={`flex-1 rounded-md border bg-card p-4 ${hit ? 'border-destructive/60' : 'border-card-border'}`}>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <p className="font-semibold">
                    {s.origin} <ArrowRight className="inline h-3.5 w-3.5" aria-hidden /> {s.destination}
                  </p>
                  <span className="font-mono text-xs text-muted-foreground">{s.provider}{s.service ? ` ${s.service}` : ''} / ref {s.bookingId}</span>
                </div>
                <p className="mt-1 text-sm">
                  <T iso={s.start} />
                  {s.end && <> <span className="text-muted-foreground">to</span> <T iso={s.end} /></>}
                </p>
                {imp && (
                  <p className={`mt-2 text-sm ${hit ? 'text-destructive' : 'text-muted-foreground'}`}>
                    <strong className="font-mono text-xs uppercase">{imp.classification}</strong> {imp.reason}
                  </p>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

function Impacts({ run }: { run: PrototypeRun }) {
  if (!run.impacts.length) return null;
  return (
    <section aria-labelledby="h-imp" className="rise">
      <SectionTitle n="02"><span id="h-imp">What this event could affect</span></SectionTitle>
      <div className="overflow-hidden rounded-md border border-border bg-card">
        {run.impacts.map((im) => {
          const seg = run.segments.find((s) => s.id === im.segmentId);
          return (
            <div key={im.segmentId} className="grid gap-1 border-b border-border p-4 last:border-0 md:grid-cols-[160px_1fr_120px] md:gap-4" data-testid={`row-impact-${im.segmentId}`}>
              <span className="font-mono text-xs uppercase text-muted-foreground">{seg ? `${seg.origin} to ${seg.destination}` : im.segmentId}</span>
              <span className="text-sm"><strong>{im.classification}.</strong> {im.reason}</span>
              <span className="font-mono text-sm md:text-right" title={im.amount === null ? 'Cost not known' : undefined}>
                {im.amount === null ? <span className="italic text-muted-foreground">Cost unknown</span> : money(im.amount, im.currency)}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function Watching() {
  return (
    <section className="rounded-md border border-dashed border-border bg-card/60 p-6" aria-labelledby="h-watch">
      <div className="flex items-center gap-3">
        <Clock className="h-5 w-5 text-muted-foreground" aria-hidden />
        <h2 id="h-watch" className="font-semibold">Watching for disruption</h2>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">No action needed yet. Recovery options appear here automatically if a delay threatens a connection.</p>
      <div className="mt-4 h-1 overflow-hidden rounded-full bg-muted"><div className="pulse-dot h-full w-1/3 bg-accent" /></div>
    </section>
  );
}

function Options({ run }: { run: PrototypeRun }) {
  const qc = useQueryClient();
  const select = useSelectPrototypeOption();
  const choose = (o: DemoOption) =>
    select.mutate(
      { id: run.id, data: { optionId: o.id, version: run.version } },
      {
        onSuccess: (r) => qc.setQueryData(getGetPrototypeRunQueryKey(r.id), r),
        onSettled: () => qc.invalidateQueries({ queryKey: getGetPrototypeRunQueryKey(run.id) }),
      },
    );
  const sorted = useMemo(() => [...run.options].sort((a, b) => Number(b.recommended) - Number(a.recommended)), [run.options]);
  if (!run.options.length)
    return <p data-testid="text-no-options" className="rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">{run.event === 'cancellation'
      ? 'No feasible replacement journey in the demo fixtures. Contact the carrier to search replacement flights; do not cancel downstream bookings. Earlier delay choices are no longer valid. Nothing has been booked or cancelled by TripGuard.'
      : run.event === 'weather_warning'
        ? 'Monitor official warnings and carrier flight status. Prepare contingency travel plans if operations change; do not cancel or rebook based on weather exposure alone.'
        : 'No recovery options are needed for this scenario.'}</p>;
  return (
    <section aria-labelledby="h-opt" className="rise">
      <SectionTitle n="03"><span id="h-opt">Recovery choices</span></SectionTitle>
      <p className="-mt-2 mb-4 text-sm text-muted-foreground">Prices are synthetic and known. Availability is <strong>unverified</strong>. Choosing records your preference only; nothing is booked.</p>
      {select.isError && <p role="alert" className="mb-3 text-sm text-destructive">That choice could not be saved, possibly because the trip changed. Review and try again.</p>}
      <div className="space-y-3">
        {sorted.map((o) => {
          const chosen = run.selectedOptionId === o.id;
          const over = o.currency === 'AUD' && o.cost > 500;
          return (
            <div key={o.id} data-testid={`card-option-${o.id}`}
              className={`rounded-md border-2 bg-card p-5 transition-colors ${chosen ? 'border-[hsl(var(--safe))]' : o.recommended ? 'border-primary' : 'border-card-border'}`}>
              <div className="flex flex-wrap items-center gap-2">
                {o.recommended && <span className="rounded-sm bg-primary px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-primary-foreground">Recommended</span>}
                <span className="rounded-sm border border-dashed border-muted-foreground/50 px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Availability unverified</span>
                {chosen && <span className="rounded-sm bg-[hsl(var(--safe))] px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-primary-foreground">Chosen / not booked</span>}
              </div>
              <h3 className="mt-2 text-lg font-bold">{o.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{o.reason}</p>
              <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
                <dl className="flex gap-6 text-sm">
                  <div><dt className="font-mono text-[10px] uppercase text-muted-foreground">Arrives</dt><dd><T iso={o.arrival} /></dd></div>
                  <div><dt className="font-mono text-[10px] uppercase text-muted-foreground">Synthetic price</dt>
                    <dd className={`font-mono ${over ? 'text-destructive' : ''}`}>{money(o.cost, o.currency)}{over && ' over budget'}</dd></div>
                </dl>
                <button data-testid={`button-choose-${o.id}`} onClick={() => choose(o)} disabled={chosen || select.isPending}
                  className={`inline-flex items-center gap-2 rounded-sm px-4 py-2 text-sm font-bold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${chosen ? 'bg-[hsl(var(--safe))] text-primary-foreground' : 'bg-primary text-primary-foreground hover:-translate-y-0.5 transition-transform disabled:opacity-60'}`}>
                  {chosen ? <><Check className="h-4 w-4" aria-hidden /> Chosen</> : select.isPending && select.variables?.data.optionId === o.id ? 'Saving...' : 'Choose this'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export function DelayControl({ run }: { run: PrototypeRun }) {
  const qc = useQueryClient();
  const sim = useSimulatePrototypeDelay();
  const eventSim = useSimulatePrototypeEvent();
  const pending = sim.isPending || eventSim.isPending;
  const [mins, setMins] = useState(run.delayMinutes);
  useEffect(() => setMins(run.delayMinutes), [run.delayMinutes]);
  const apply = () =>
    sim.mutate(
      { id: run.id, data: { minutes: mins } },
      {
        onSuccess: (r) => qc.setQueryData(getGetPrototypeRunQueryKey(r.id), r),
        onSettled: () => qc.invalidateQueries({ queryKey: getGetPrototypeRunQueryKey(run.id) }),
      },
    );
  const applyEvent = (event: 'cancellation' | 'weather_warning' | 'forecast') =>
    eventSim.mutate({ id: run.id, data: { event, version: run.version } }, {
      onSuccess: (r) => qc.setQueryData(getGetPrototypeRunQueryKey(r.id), r),
      onSettled: () => qc.invalidateQueries({ queryKey: getGetPrototypeRunQueryKey(run.id) }),
    });
  return (
    <section className="rounded-md border border-border bg-card p-4" aria-labelledby="h-sim">
      <h2 id="h-sim" className="font-semibold">Simulate a disruption</h2>
      <p className="mt-1 text-xs text-muted-foreground">Each control replaces the current scenario and clears earlier recovery choices. All events are fictional, including the official-warning fixture; no live sources are connected.</p>
      <p className="mt-2 text-xs font-semibold">Current scenario: {run.event?.replaceAll('_', ' ') ?? 'delay'}</p>
      <div className="mt-3 grid gap-2">
        {([
          ['cancellation', 'Simulate EX101 cancellation (S02)'],
          ['weather_warning', 'Simulate official weather warning (S03)'],
          ['forecast', 'Simulate forecast only'],
        ] as const).map(([event, label]) => (
          <button key={event} data-testid={`button-simulate-${event}`} onClick={() => applyEvent(event)}
            disabled={pending || run.event === event}
            className="rounded-sm border border-border px-3 py-2 text-left text-sm font-semibold disabled:opacity-50">
            {label}
          </button>
        ))}
      </div>
      {eventSim.isError && <p role="alert" className="mt-2 text-xs text-destructive">Scenario could not be applied. Review the refreshed trip and retry.</p>}
      <label htmlFor="delay" className="mt-4 flex justify-between font-mono text-sm">
        <span>First flight delay</span><strong>{mins} min</strong>
      </label>
      <input id="delay" data-testid="input-delay" type="range" min={0} max={180} step={5} value={mins}
        onChange={(e) => setMins(Number(e.target.value))} className="mt-2 w-full accent-[hsl(var(--primary))]" />
      <div className="flex justify-between font-mono text-[10px] text-muted-foreground"><span>0</span><span>90</span><span>180</span></div>
      <button data-testid="button-apply-delay" onClick={apply} disabled={pending || (mins === run.delayMinutes && (!run.event || run.event === 'delay'))}
        className="mt-3 w-full rounded-sm bg-accent py-2 text-sm font-bold text-accent-foreground disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-ring">
        {sim.isPending ? 'Recalculating...' : 'Apply delay'}
      </button>
      {sim.isError && <p role="alert" className="mt-2 text-xs text-destructive">Delay could not be applied.</p>}
    </section>
  );
}

function AlertLog({ run }: { run: PrototypeRun }) {
  return (
    <section className="rounded-md border border-border bg-card p-4" aria-labelledby="h-alerts">
      <h2 id="h-alerts" className="font-semibold">Alerts</h2>
      {run.alerts.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">Quiet so far. Alerts appear here in-app only.</p>
      ) : (
        <ul className="mt-2 space-y-2">
          {[...run.alerts].reverse().map((a) => (
            <li key={a.id} className="border-l-2 border-accent pl-3 text-sm" data-testid={`row-alert-${a.id}`}>
              <p className="font-mono text-[10px] uppercase text-muted-foreground">{a.level} / <T iso={a.createdAt} /></p>
              <p>{a.text}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Activity({ run }: { run: PrototypeRun }) {
  if (!run.activity.length) return null;
  return (
    <section className="rounded-md border border-border bg-card p-4" aria-labelledby="h-act">
      <h2 id="h-act" className="font-semibold">Activity</h2>
      <ol className="mt-2 space-y-1 font-mono text-xs text-muted-foreground">
        {run.activity.map((a, i) => <li key={i}>{String(i + 1).padStart(2, '0')} {a}</li>)}
      </ol>
    </section>
  );
}

export function ItineraryJson({ json }: { json: string }) {
  const pretty = useMemo(() => {
    try { return JSON.stringify(JSON.parse(json), null, 2); } catch { return json; }
  }, [json]);
  return (
    <details className="group rounded-md border border-border bg-card">
      <summary data-testid="button-toggle-itinerary" className="flex cursor-pointer items-center justify-between px-4 py-3 text-sm font-semibold">
        Structured itinerary <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" aria-hidden />
      </summary>
      <pre className="max-h-96 overflow-auto border-t border-border p-4 font-mono text-[11px] leading-relaxed" data-testid="text-itinerary-json">{pretty}</pre>
    </details>
  );
}

// keep sample query key referenced for cache consumers
export const sampleKey = getGetPrototypeSampleQueryKey;
