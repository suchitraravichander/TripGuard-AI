import app from "./app";
import { logger } from "./lib/logger";
import { tripRuntime } from "./tripguard/service.ts";
import { tickPrototype } from "./tripguard/prototype.ts";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

const stopTripRuntime = tripRuntime.start(60_000, (err) => logger.error({ err }, "TripGuard simulation tick failed"));
let prototypeBusy = false;
const prototypeTimer = setInterval(async () => {
  if (prototypeBusy) return;
  prototypeBusy = true;
  try { await tickPrototype(); } catch (err) { logger.error({ err }, "Prototype tick failed"); }
  finally { prototypeBusy = false; }
}, 1000);
prototypeTimer.unref();
for (const signal of ["SIGTERM", "SIGINT"] as const) {
  process.once(signal, () => {
    stopTripRuntime();
    clearInterval(prototypeTimer);
    server.close();
  });
}
