import { Router, type IRouter } from "express";
import healthRouter from "./health";
import prototypeRouter from "./prototype";
import tripguardRouter from "./tripguard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(prototypeRouter);
router.use(tripguardRouter);

export default router;
