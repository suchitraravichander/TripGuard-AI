import { Router } from "express";
import { tripRuntime } from "../tripguard/service.ts";

const router = Router();
router.get("/tripguard/runtime", async (_req, res, next) => {
  try {
    const state = await tripRuntime.read();
    res.json({
      mode: "simulation", version: state.version, checkedAt: state.checkedAt,
      lastError: state.lastError, notificationCount: state.notifications.length,
      liveStatus: "blocked", intervalSeconds: 60,
      limitation: "Synthetic hero only. Local single-process persistence. No external notifications or booking changes.",
    });
  } catch (error) { next(error); }
});
router.get("/tripguard/hero", async (_req, res, next) => {
  try {
    const state = await tripRuntime.read();
    if (!state.result) {
      res.status(503).json({ error: state.lastError ?? "Waiting for first scheduled check" });
      return;
    }
    res.json(state.result);
  } catch (error) { next(error); }
});
export default router;
