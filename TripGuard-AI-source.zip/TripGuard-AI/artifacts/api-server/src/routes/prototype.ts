import { Router } from "express";
import { GetPrototypeRunResponse, SimulatePrototypeDelayBody, SimulatePrototypeEventBody, SelectPrototypeOptionBody } from "@workspace/api-zod";
import { createDemo, readDemo, saveDemo, delayedRun, eventRun, selectedRun, sampleEmail } from "../tripguard/prototype.ts";

const router = Router();
// Public synthetic demo only. No personal data, user uploads, external writes or accounts.
router.use("/prototype", (_req, res, next) => { res.set("Cache-Control", "no-store"); next(); });
router.get("/prototype/sample", (_req, res) => { res.json(sampleEmail); });
router.post("/prototype/runs", async (_req, res) => { res.status(201).json(GetPrototypeRunResponse.parse(await createDemo())); });
router.param("id", (req, res, next, id: string) => {
  if (!/^[0-9a-f-]{36}$/.test(id)) { res.status(400).json({ error: "Invalid demo ID" }); return; }
  next();
});
router.get("/prototype/runs/:id", async (req, res) => {
  const run = await readDemo(String(req.params.id));
  if (!run) { res.status(404).json({ error: "Demo not found. Start a new demo." }); return; }
  res.json(run);
});
router.post("/prototype/runs/:id/delay", async (req, res) => {
  const body = SimulatePrototypeDelayBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Delay must be an integer between 0 and 180." }); return; }
  const old = await readDemo(String(req.params.id));
  if (!old) { res.status(404).json({ error: "Demo not found" }); return; }
  const next = delayedRun(old, body.data.minutes);
  if (!await saveDemo(old, next)) { res.status(409).json({ error: "Demo changed. Refresh and retry." }); return; }
  res.json(GetPrototypeRunResponse.parse(next));
});
router.post("/prototype/runs/:id/event", async (req, res) => {
  const body = SimulatePrototypeEventBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Valid simulated event and current version required." }); return; }
  const old = await readDemo(String(req.params.id));
  if (!old) { res.status(404).json({ error: "Demo not found" }); return; }
  if (body.data.version !== old.version) { res.status(409).json({ error: "Demo changed. Refresh and retry." }); return; }
  const next = eventRun(old, body.data.event);
  if (!await saveDemo(old, next)) { res.status(409).json({ error: "Demo changed. Refresh and retry." }); return; }
  res.json(GetPrototypeRunResponse.parse(next));
});
router.post("/prototype/runs/:id/selection", async (req, res) => {
  const body = SelectPrototypeOptionBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Option and current version required." }); return; }
  const old = await readDemo(String(req.params.id));
  if (!old) { res.status(404).json({ error: "Demo not found" }); return; }
  if (body.data.version !== old.version) { res.status(409).json({ error: "Assessment changed. Review the latest options." }); return; }
  if (body.data.optionId !== null && !old.options.some(o => o.id === body.data.optionId)) { res.status(400).json({ error: "Option unavailable" }); return; }
  const next = selectedRun(old, body.data.optionId, body.data.version);
  if (!await saveDemo(old, next)) { res.status(409).json({ error: "Assessment changed. Refresh." }); return; }
  res.json(GetPrototypeRunResponse.parse(next));
});
export default router;
