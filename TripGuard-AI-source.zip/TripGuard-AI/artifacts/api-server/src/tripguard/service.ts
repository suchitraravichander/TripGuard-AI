import { resolve } from "node:path";
import { TripRuntime } from "./runtime.ts";

// Managed API workflow runs from artifacts/api-server.
export const tripRuntime = new TripRuntime(resolve(".local/tripguard/simulation-state.json"));
