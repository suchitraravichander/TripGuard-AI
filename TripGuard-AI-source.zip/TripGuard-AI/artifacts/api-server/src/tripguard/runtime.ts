import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { baseline, delayedFeed } from "./fixtures.ts";
import { runHero, type Feed, type Notification } from "./engine.ts";

export interface Provider {
  mode: "simulation" | "live";
  check(): Promise<Feed>;
}
export class SyntheticProvider implements Provider {
  mode = "simulation" as const;
  async check() { return { ...delayedFeed }; }
}
export class UnconnectedLiveProvider implements Provider {
  mode = "live" as const;
  async check(): Promise<Feed> {
    throw new Error("Live flight status blocked: no approved connector connected. No simulated fallback.");
  }
}
export interface RuntimeState {
  version: number; mode: "simulation"; checkedAt: string | null;
  lastError: string | null; lastFeed: Feed;
  notifications: Notification[]; result: ReturnType<typeof runHero> | null;
}
const initial = (): RuntimeState => ({ version: 0, mode: "simulation", checkedAt: null,
  lastError: null, lastFeed: baseline, notifications: [], result: null });

// Single-process demo worker: serial queue + atomic replacement. Not multi-instance storage.
export class TripRuntime {
  private queue: Promise<unknown> = Promise.resolve();
  private file: string;
  private provider: Provider;
  constructor(file: string, provider: Provider = new SyntheticProvider()) {
    this.file = file;
    this.provider = provider;
  }
  async read(): Promise<RuntimeState> {
    try {
      const state = JSON.parse(await readFile(this.file, "utf8")) as RuntimeState;
      if (!Number.isInteger(state.version) || !Array.isArray(state.notifications) || !state.lastFeed)
        throw new Error("Invalid runtime state; refusing to overwrite");
      return state;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return initial();
      throw error;
    }
  }
  tick(): Promise<RuntimeState> {
    const next = this.queue.then(async () => {
      const state = await this.read();
      try {
        // Until a live adapter and real-trip validation exist, never process real data.
        if (this.provider.mode !== "simulation") throw new Error("Live runtime blocked pending approved adapter and real-trip validation");
        const feed = await this.provider.check();
        state.result = runHero(state.lastFeed, feed, state.notifications.map(n => n.key));
        if (state.result.alert) state.notifications.push(state.result.alert);
        state.lastFeed = feed;
        state.lastError = null;
      } catch (error) {
        state.lastError = error instanceof Error ? error.message : "Provider failed";
        state.result = null;
      }
      state.checkedAt = new Date().toISOString();
      state.version += 1;
      await mkdir(dirname(this.file), { recursive: true });
      await writeFile(`${this.file}.tmp`, JSON.stringify(state, null, 2));
      await rename(`${this.file}.tmp`, this.file);
      return state;
    });
    this.queue = next.catch(() => undefined);
    return next;
  }
  start(intervalMs: number, onError: (error: unknown) => void) {
    if (intervalMs < 10) throw new Error("Invalid interval");
    let busy = false;
    const tick = async () => {
      if (busy) return;
      busy = true;
      try { await this.tick(); } catch (error) { onError(error); }
      finally { busy = false; }
    };
    void tick();
    const timer = setInterval(() => void tick(), intervalMs);
    timer.unref();
    return () => clearInterval(timer);
  }
}
