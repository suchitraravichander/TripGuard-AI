import assert from "node:assert/strict";
import { mkdir, writeFile, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { mailbox, observedAt, delayedFeed } from "./fixtures.ts";
import { assess, extractBookings, monitor, notify, recovery, runHero } from "./engine.ts";
import { approve, execute, preview, revise } from "./actions.ts";
import { SyntheticProvider, TripRuntime, UnconnectedLiveProvider } from "./runtime.ts";

type Row = { id: string; criterion: string; status: "PASS" | "FAIL" | "BLOCKED"; evidence: string };
const rows: Row[] = [];
function check(id: string, criterion: string, test: () => void, evidence: string) {
  try { test(); rows.push({ id, criterion, status: "PASS", evidence }); }
  catch (e) { rows.push({ id, criterion, status: "FAIL", evidence: String(e) }); }
}
function blocked(id: string, criterion: string, evidence: string) {
  rows.push({ id, criterion, status: "BLOCKED", evidence });
}
const hero = runHero();
const { trip, snapshot, risk } = hero;
const constraints = { latestArrival: "2026-12-06T00:00:00+11:00", budget: 500, companions: "Solo" };
const options = recovery(constraints).options;
const draft = preview("carrier@example.invalid", "Please confirm a later flight and any cost before changing my booking.", 1);
const approved = approve(draft, draft.hash, 2, observedAt);
const temp = await mkdtemp(join(tmpdir(), "tripguard-"));
try {
  const file = join(temp, "runtime.json");
  const runtime = new TripRuntime(file);
  const first = await runtime.tick();
  const restarted = new TripRuntime(file);
  const second = await restarted.tick();

  blocked("1.1", "Gmail connection through an approved connector", "No Gmail connection; synthetic mailbox used. Live read permissions and privacy review required.");
  blocked("1.2", "Disclose live Gmail search scope", "No live search attempted. Fixture disclosure does not claim a Gmail search.");
  check("1.3", "Continue without Gmail and disclose it", () => assert.match(trip.disclosure, /Gmail was not searched/), trip.disclosure);
  check("2.1", "Extract all four bookings with provenance", () => {
    assert.equal(trip.segments.length, 4);
    assert.deepEqual(trip.segments.map(s => s.source.id), mailbox.slice(0, 4).map(m => m.id));
    assert.ok(trip.segments.every(s => s.source.sentAt));
  }, "Four labelled synthetic messages parsed; source IDs and dates retained.");
  check("2.2", "Keep offsets and zones at both ends", () => {
    const s = trip.segments[0]!;
    assert.ok(s.start.endsWith("+05:30") && s.end!.endsWith("+08:00"));
    assert.equal(s.startZone, "Asia/Kolkata"); assert.equal(s.endZone, "Asia/Singapore");
  }, "EX101 preserves Indian departure and Singapore arrival zones.");
  check("2.3", "Unknown fields stay null", () => {
    assert.ok(trip.segments.every(s => s.fare === null && s.driverWaitMinutes === null && s.hotelCutoff === null));
  }, "Fare, wait allowance and cutoff remain null; no invented values.");
  check("2.4", "Injected instruction produces no action", () => {
    assert.deepEqual(trip.ignoredMessages, ["mail-injection"]); assert.deepEqual(hero.actions, []);
    assert.match(trip.disclosure, /ignored/);
  }, "Unsupported injected message ignored; no actions created. Tests fixture parser, not an LLM security guarantee.");
  check("2.5", "Ambiguous date is flagged", () => {
    const ambiguous = { ...mailbox[0]!, body: mailbox[0]!.body.replace("2026-12-04T06:10:00+05:30", "03/04/2026") };
    assert.ok(extractBookings([ambiguous]).flags.includes("date_ambiguous"));
  }, "Ambiguous date perturbation rejected instead of interpreted.");
  check("3.1", "Graph includes flights, layover, hotel nights and transfer", () => {
    assert.equal(trip.nodes.length, 7);
    assert.equal(trip.nodes.filter(n => n.type === "hotel_night").length, 2);
    assert.ok(trip.nodes.some(n => n.type === "prepaid_transfer"));
  }, "Seven nodes including two hotel nights.");
  check("3.2", "Persist typed dependency edges", () => {
    assert.deepEqual(trip.edges.slice(0, 3), [
      { from: "seg_001", to: "seg_002", type: "connection" },
      { from: "seg_002", to: "seg_004", type: "transfer_pickup" },
      { from: "seg_002", to: "seg_003", type: "hotel_checkin" },
    ]);
    assert.ok(trip.edges.some(e => e.to === "night_2026-12-04"));
  }, "Connection, pickup, hotel check-in and night-coverage edges asserted.");
  check("3.3", "Graph survives state reload", () => {
    assert.deepEqual(second.result!.trip.edges, trip.edges);
  }, "New runtime instance loaded state and recomputed the same persisted graph.");
  check("4.1", "Snapshot contains time, source and reliability", () => {
    assert.equal(snapshot.checkedAt, observedAt); assert.equal(snapshot.reliability, "simulated");
    assert.ok(snapshot.source);
  }, "Simulation provenance explicit; fixture observation time retained.");
  check("4.2", "Missing status listed as not checked", () => assert.equal(snapshot.notChecked[0]!.segmentId, "seg_002"), "EX212 explicitly not checked.");
  check("4.3", "No status inferred from silence", () => {
    assert.match(snapshot.notChecked[0]!.reason, /No approved/);
    assert.equal(second.result!.snapshot.changes.length, 0);
  }, "Missing source remains missing; unchanged known data does not create a change.");
  check("4.4", "Forecast is not an official warning", () => {
    assert.equal(snapshot.weather.kind, "forecast"); assert.equal(snapshot.weather.officialWarning, false);
  }, "Synthetic thunderstorms retained as forecast only.");
  check("5.1", "Detect +40-minute change", () => {
    assert.equal(snapshot.changes.length, 1);
    assert.deepEqual(snapshot.changes[0], { segmentId: "seg_001", type: "time_moved", from: 0, to: 40, minutes: 40, observedAt });
  }, "One normalized time_moved event with before/after and timestamp.");
  check("5.2", "Repeat check produces no change", () => assert.deepEqual(monitor(delayedFeed, delayedFeed).changes, []), "Identical feed produces zero changes.");
  check("6.1", "Predicted arrival and 50-minute connection", () => {
    assert.equal(risk.predictedArrival, "2026-12-04T05:50:00.000Z"); assert.equal(risk.remaining, 50);
  }, "05:50 UTC = 13:50 Singapore; departure 14:40 leaves 50 minutes.");
  check("6.2", "R1 produces High risk from placeholder slack", () => {
    assert.equal(risk.scheduledLayover - risk.minimum, 0); assert.equal(risk.level, "High"); assert.deepEqual(risk.rules, ["R1"]);
  }, "40-minute delay exceeds zero planning slack.");
  check("6.3", "Confidence reflects placeholder evidence", () => assert.equal(risk.confidence, "medium"), "Medium, not high, confidence.");
  check("6.4", "No unsupported verdict or invented percentage", () => {
    assert.equal(risk.classification, "at_risk"); assert.match(risk.basis, /not an airline rule/);
    assert.ok(!hero.reply.includes("%"));
  }, "At risk rather than confirmed missed; no probability claim.");
  check("6.5", "Unknown decision deadline remains unknown", () => assert.equal(risk.deadline, null), "No invented deadline.");
  check("7.1", "Reconciled: planning threshold means at risk, not missed", () => assert.equal(risk.classification, "at_risk"), "Supersedes the original unsupported 'missed' expectation.");
  check("7.2", "Reconciled: same booking does not prove rebooking coverage", () => assert.match(risk.protection, /terms unverified/), "Booking grouping recorded; entitlement not asserted.");
  check("7.3", "Transfer cost known; loss conditional", () => {
    const impact = risk.consequences[0]!;
    assert.equal(impact.amount, 65); assert.equal(impact.classification, "at_risk"); assert.match(impact.reason, /unknown/);
  }, "AUD 65 at stake; no confirmed loss without replacement timing.");
  check("7.4", "Hotel at risk with unknown cost", () => {
    assert.equal(risk.consequences[1]!.amount, null); assert.equal(risk.consequences[1]!.classification, "at_risk");
  }, "Unknown hotel cost is not zero and hotel night is not declared lost.");
  check("7.5", "Known cost precedes unknown within conditional impacts", () => {
    assert.equal(risk.consequences[0]!.segmentId, "seg_004"); assert.equal(risk.consequences[1]!.segmentId, "seg_003");
  }, "Reconciled both as conditional at-risk impacts, not confirmed severe losses.");
  check("7.6", "Missing return not called unaffected", () => assert.equal(risk.returnJourney, "No return booking in the file"), risk.returnJourney);
  check("8.1", "Ask for constraints before recovery ranking", () => {
    assert.equal(hero.recovery.options.length, 0); assert.equal((hero.reply.match(/\?/g) ?? []).length, 1);
    assert.equal(hero.constraints, null);
  }, "One question asks arrival, budget and companions.");
  check("8.2", "At least three options across two families", () => {
    assert.equal(options.length, 3); assert.ok(new Set(options.map(o => o.family)).size >= 2);
  }, "Three synthetic options: same carrier, another carrier, next day.");
  check("8.3", "Each option identifies source and check time", () => assert.ok(options.every(o => o.checkedAt && o.source.startsWith("Synthetic"))), "All options visibly synthetic and availability unverified.");
  check("8.4", "Rank by downstream impact, arrival then cost", () => {
    assert.deepEqual(options.map(o => o.id), ["option-2", "option-1", "option-3"]);
  }, "Confidence equal across these fixtures; earlier arrival breaks first tie.");
  check("8.5", "Recovery books nothing", () => assert.ok(options.every(o => !o.booked)), "No booking transport exists.");
  check("9.1", "High risk produces one action-recommended alert", () => assert.equal(hero.alert!.level, "action_recommended"), "One alert returned to orchestrated result.");
  check("9.2", "Alert explains change, impact, action, freshness and deadline", () => {
    for (const text of ["40 minutes", "50 minutes", "transfer", "Compare recovery", "deadline unknown", observedAt])
      assert.ok(hero.alert!.text.includes(text));
  }, "All required alert details checked.");
  check("9.3", "No invented travel-time claim", () => assert.ok(!hero.alert!.text.includes("leave by")), "No departure-from-hotel advice without a travel-time source.");
  check("9.4", "Alert deduplicates across runtime restart", () => {
    assert.equal(first.notifications.length, 1); assert.equal(second.notifications.length, 1);
    assert.equal(second.result!.alert, null);
  }, "Durable event key survives new runtime instance.");
  blocked("9.5", "Deliver a proactive live alert", "Scheduled simulation is separately tested below; approved external delivery channel and live provider remain unavailable.");
  check("10.1", "Preview prepared without execution", () => {
    assert.equal(draft.status, "awaiting_approval"); assert.ok(draft.text && draft.recipient && draft.hash);
  }, "Synthetic class-1 draft only.");
  check("10.2", "Only exact later-turn approval accepted", () => {
    assert.throws(() => approve(draft, draft.hash, 1, observedAt));
    assert.throws(() => approve(draft, "wrong", 2, observedAt));
    assert.equal(approved.status, "approved");
  }, "Same-turn and mismatched approvals rejected.");
  check("10.3", "Changed preview invalidates approval", () => {
    const changed = revise(approved, "Different offer at a different price.");
    assert.equal(changed.status, "stale"); assert.equal(changed.approvedAt, null);
    assert.throws(() => approve(changed, draft.hash, 3, observedAt));
  }, "Modified terms require a fresh preview and approval.");
  check("10.4", "Non-refundable transfer not cancelled", () => {
    assert.deepEqual(hero.actions, []); assert.throws(() => execute(approved), /read-only/);
  }, "All external actions disabled under connector policy.");
  blocked("10.5", "Execute and verify action with persistent action ledger", "Draft approval gates tested; external execution, provider verification and production action ledger are not implemented.");

  check("R.1", "No delay does not raise R1 at exactly zero slack", () => assert.equal(assess(trip, 0).level, "Low"), "Strictly below threshold is required; avoids an alert on a valid boundary.");
  check("R.2", "Authoritative minimum can support missed classification", () => assert.equal(assess(trip, 40, "A").classification, "missed"), "Tier A and Tier C handled differently.");
  check("R.3", "Escalation to Critical produces a new urgent alert", () => {
    const critical = assess(trip, 100);
    assert.equal(notify(critical, [hero.alert!.key], observedAt)!.level, "urgent");
  }, "Level change bypasses previous High-risk deduplication.");
  check("R.4", "Budget hard constraint excludes unaffordable options", () => {
    assert.ok(recovery({ ...constraints, budget: 100 }).options.every(o => o.cost <= 100));
  }, "Only qualifying fixture options remain.");
  check("R.5", "Concurrent ticks serialize state versions", () => assert.equal(second.version, 2), "Restart increments persisted version.");
  const concurrent = await Promise.all([restarted.tick(), restarted.tick()]);
  check("R.6", "Concurrent writes retain both increments", () => assert.deepEqual(concurrent.map(s => s.version), [3, 4]), "Single-process queue prevents lost updates.");
  const unavailable = await new TripRuntime(join(temp, "live.json"), new UnconnectedLiveProvider()).tick();
  check("R.7", "Unavailable live mode fails closed", () => {
    assert.match(unavailable.lastError!, /blocked/); assert.equal(unavailable.result, null);
    assert.equal(unavailable.notifications.length, 0);
  }, "No synthetic fallback in live mode.");
  let calls = 0;
  class CountedProvider extends SyntheticProvider {
    override async check() { calls++; return super.check(); }
  }
  const scheduled = new TripRuntime(join(temp, "scheduled.json"), new CountedProvider());
  const stop = scheduled.start(20, () => undefined);
  await new Promise(r => setTimeout(r, 100));
  stop();
  check("R.8", "Scheduler invokes flow without browser requests", () => assert.ok(calls >= 2), `${calls} scheduled simulated checks observed; not external delivery.`);
  await restarted.tick(); // drain writes before temporary directory cleanup
} finally {
  await rm(temp, { recursive: true, force: true });
}

const counts = Object.fromEntries(["PASS", "FAIL", "BLOCKED"].map(s => [s, rows.filter(r => r.status === s).length]));
const report = { generatedAt: new Date().toISOString(), scope: "Synthetic offline integration; no live sources or external actions", counts, rows };
const output = resolve(import.meta.dirname, "../../../../generated-artifacts/tripguard");
await mkdir(output, { recursive: true });
await writeFile(join(output, "acceptance.json"), JSON.stringify(report, null, 2));
await writeFile(join(output, "hero-output.json"), JSON.stringify(hero, null, 2));
const escape = (s: string) => s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
await writeFile(join(output, "acceptance.html"), `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TripGuard integration results</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:40px auto;padding:0 20px;color:#162e34;background:#f5faf9}h1{color:#086859}table{border-collapse:collapse;width:100%;background:white}th,td{text-align:left;padding:12px;border-bottom:1px solid #d7e4e0;vertical-align:top}th{background:#dcefe9}.PASS{color:#12603c}.FAIL{color:#a02020}.BLOCKED{color:#79520c}small{color:#425955}@media(max-width:650px){table,tbody,tr,td{display:block}thead{display:none}tr{border:1px solid #cadbd5;margin:12px 0}}</style><h1>TripGuard AI: hero integration results</h1><p><strong>${counts.PASS} passed · ${counts.FAIL} failed · ${counts.BLOCKED} blocked</strong></p><p>${report.scope}. Generated ${report.generatedAt}.</p><p>The first 43 rows map to every original hero acceptance criterion. Rows 7.1–7.5 use reconciled evidence-safe expectations. PASS means the implemented synthetic fixture path passed, not that live email parsing or provider integrations were verified. BLOCKED means not tested, never passed.</p><table><thead><tr><th>ID</th><th>Criterion</th><th>Result</th><th>Evidence / limitation</th></tr></thead><tbody>${rows.map(r => `<tr><td>${escape(r.id)}</td><td>${escape(r.criterion)}</td><td class="${r.status}">${r.status}</td><td>${escape(r.evidence)}</td></tr>`).join("")}</tbody></table></html>`);
console.log(JSON.stringify(report, null, 2));
if (counts.FAIL) process.exitCode = 1;
