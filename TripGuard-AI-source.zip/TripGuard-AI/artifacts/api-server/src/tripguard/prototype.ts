import { randomUUID } from "node:crypto";
import { db, prototypeRunsTable } from "@workspace/db";
import { and, eq, lte, isNotNull } from "drizzle-orm";
import { GetPrototypeRunResponse } from "@workspace/api-zod";
import { assess, extractBookings, notify, recovery } from "./engine.ts";
import { mailbox } from "./fixtures.ts";
import { scenarios } from "./evaluation/scenarios.ts";

export type DemoRun = ReturnType<typeof GetPrototypeRunResponse.parse>;
export const sampleEmail = {
  subject: "Your Chennai–Singapore–Sydney trip is confirmed · SIM7F2",
  from: "Example Travel <bookings@example.invalid>",
  body: `Hello traveller,\n\nYour sample travel itinerary is confirmed. All bookings below are fictional.\n\n${mailbox.slice(0, 4).map(m => `[Booking]\n${m.body}`).join("\n\n")}\n\nThis is a demonstration email, not a real reservation.`,
};
function parseSample() {
  const blocks = sampleEmail.body.split("[Booking]\n").slice(1);
  return extractBookings(blocks.map(body => ({ id: "sample-confirmation-email", sentAt: "2026-11-20T09:00:00Z", body })));
}
export function initialRun(now = new Date()): DemoRun {
  const trip = parseSample();
  if (trip.segments.length !== 4 || trip.flags.length) throw new Error("Sample extraction failed");
  return {
    id: randomUUID(), version: 1, phase: "monitoring", createdAt: now.toISOString(),
    dueAt: new Date(now.getTime() + 8000).toISOString(), delayMinutes: 0,
    riskLevel: "Low", remainingMinutes: 90,
    reasoning: "90-minute scheduled Singapore layover. The 90-minute minimum is a planning placeholder, not an airline rule. A simulated 40-minute delay will arrive after 8 seconds.",
    segments: trip.segments, itineraryJson: JSON.stringify(trip, null, 2),
    impacts: [], options: [], alerts: [], selectedOptionId: null,
    activity: ["Mock booking email received.", "Four bookings extracted with time zones and provenance.", "Itinerary and dependency graph saved.", "Simulation armed: EX101 +40 minutes after 8 seconds."],
  };
}
export function delayedRun(old: DemoRun, minutes: number, now = new Date()): DemoRun {
  if (!Number.isInteger(minutes) || minutes < 0 || minutes > 180) throw new Error("Invalid delay");
  if (old.delayMinutes === minutes && !old.dueAt && (!old.event || old.event === "delay")) return old;
  const trip = JSON.parse(old.itineraryJson) as ReturnType<typeof extractBookings>;
  const risk = assess(trip, minutes);
  const notification = notify(risk, [], now.toISOString());
  const choices = minutes > 0 ? recovery({
    latestArrival: "2026-12-06T00:00:00+11:00", budget: 500, companions: "Solo",
  }).options : [];
  const titles: Record<string, string> = {
    another_carrier: "Earlier arrival · another carrier",
    same_carrier: "Later departure · Example Air",
    next_day: "Next-day departure",
  };
  const alerts = [...old.alerts];
  if (notification) alerts.push({ id: `${old.id}:${old.version + 1}`, level: notification.level,
    text: notification.text, createdAt: now.toISOString() });
  else if (old.delayMinutes > 0 || (old.event && old.event !== "delay")) alerts.push({ id: `${old.id}:${old.version + 1}`, level: "info",
    text: "Previous simulated disruption cleared. Connection returns to its 90-minute planning margin. No booking has changed.",
    createdAt: now.toISOString() });
  return {
    ...old, version: old.version + 1, dueAt: null, event: "delay",
    phase: minutes > 0 ? "action_required" : "monitoring", delayMinutes: minutes,
    riskLevel: risk.level, remainingMinutes: risk.remaining, selectedOptionId: null,
    reasoning: `90 scheduled minutes − ${minutes} delay minutes = ${risk.remaining} connection minutes. ${risk.basis}. ${risk.classification === "missed" ? "Predicted inbound arrival is at or after onward departure." : minutes > 0 ? "The connection is at risk, not confirmed missed." : "No delay is reported in this simulation."} Confidence: ${risk.confidence}. ${risk.protection}. Decision deadline unknown.`,
    impacts: risk.consequences,
    options: choices.map((o, i) => ({ id: o.id, title: titles[o.family]!, arrival: o.arrival,
      cost: o.cost, currency: "AUD", recommended: i === 0,
      reason: `Synthetic estimate: ${o.brokenItems} downstream booking(s) affected. ${i === 0 ? "Ranked first by fewer affected bookings, then earlier arrival." : "Ranked by downstream impact, then arrival."} Seats, fares and protection are unverified.` })),
    alerts: alerts.slice(-20),
    activity: [...old.activity, `Simulated EX101 delay: ${minutes} minutes.`, `Risk assessed: ${risk.level}. Downstream impacts recalculated.`,
      ...(notification ? ["In-app alert generated automatically.", "Three simulated recovery options ranked using demo constraints."] : ["No recovery required."]),
      ...(old.options.length ? ["Previous recovery choices and selection invalidated because the scenario changed."] : [])].slice(-30),
  };
}
/** Each control replaces the previous demo scenario; it is not a live status update. */
export function eventRun(old: DemoRun, event: "cancellation" | "weather_warning" | "forecast", now = new Date()): DemoRun {
  if (old.event === event && !old.dueAt) return old;
  const cancellation = scenarios.find(s => s.id === "S02")!;
  const weather = scenarios.find(s => s.id === "S03")!;
  const w = weather.input;
  const flight = old.segments.find(s => s.origin === w.airport && s.type === "flight");
  const relevant = !!flight && w.official === true &&
    Date.parse(flight.start) >= Date.parse(String(w.validFrom)) &&
    Date.parse(flight.start) <= Date.parse(String(w.validTo));
  const cancelled = event === "cancellation";
  const warning = event === "weather_warning" && relevant;
  const text = cancelled
    ? `Simulated carrier cancellation: ${cancellation.input.flight} is cancelled, even with 0 delay minutes. Critical: seek replacement flights before travelling. Do not cancel downstream bookings.`
    : warning
      ? `Simulated official-weather-warning fixture: ${w.warning} at ${w.airport}, valid ${w.validFrom} to ${w.validTo}, overlaps departure ${flight!.start}. High weather exposure; this is not a flight cancellation or confirmed downstream loss. Monitor carrier status and prepare contingencies.`
      : event === "forecast"
        ? "Simulated thunderstorm forecast only, not an official warning. No flight cancellation or confirmed downstream loss. Monitor official warnings and carrier status."
        : "Simulated official-weather-warning fixture does not overlap this itinerary's airport and departure time. No relevant weather exposure identified.";
  return {
    ...old, version: old.version + 1, event, dueAt: null, delayMinutes: 0,
    phase: cancelled || warning ? "action_required" : "monitoring",
    riskLevel: cancelled ? "Critical" : warning ? "High" : "Low",
    remainingMinutes: cancelled ? null : 90, selectedOptionId: null, options: [],
    reasoning: `${text} ${cancelled ? "No feasible replacement journey is available in the demo fixtures; earlier delay options are not valid replacements for a cancelled first flight. Contact the carrier to search a replacement journey. Protection and costs unverified." : "The scheduled connection remains 90 minutes; no operational delay is confirmed."} Source is synthetic, not a live official feed. Decision deadline unknown. No booking changed.`,
    impacts: (cancelled ? cancellation.affected : warning ? [flight!.id] : []).map(segmentId => ({
      segmentId, classification: cancelled ? "at_risk" : "weather_exposure", amount: null, currency: null,
      reason: cancelled ? "The cancelled first flight breaks the planned journey. This downstream booking is at risk, not cancelled; loss and revised arrival remain unconfirmed."
        : "Departure overlaps the simulated official warning. Monitor flight status; no delay or cancellation is confirmed.",
    })),
    alerts: [...old.alerts, { id: `${old.id}:${old.version + 1}`, level: cancelled ? "urgent" : warning ? "action_recommended" : "info",
      text, createdAt: now.toISOString() }].slice(-20),
    activity: [...old.activity, `Replaced demo scenario with simulated ${event}.`, text,
      "Previous recovery choices and selection invalidated; scheduled delay timer disarmed.",
      ...(cancelled ? ["Cancellation warning generated before replacement search.", "No feasible replacement fixture. Manual carrier contact required; downstream bookings unchanged."] : [])].slice(-30),
  };
}
export function selectedRun(old: DemoRun, optionId: string | null, version: number): DemoRun {
  if (version !== old.version) throw new Error("STALE");
  if (optionId === null) return { ...old, version: old.version + 1, selectedOptionId: null,
    phase: old.options.length ? "action_required" : "monitoring",
    activity: [...old.activity, "Recovery preference cleared. Original bookings unchanged."].slice(-30) };
  const option = old.options.find(o => o.id === optionId);
  if (!option) throw new Error("OPTION");
  if (old.selectedOptionId === optionId) return old;
  return { ...old, version: old.version + 1, phase: "selected", selectedOptionId: optionId,
    activity: [...old.activity, `Selected ${option.title}. Choice saved; not booked. Contact the carrier to verify the offer and arrange changes.`].slice(-30) };
}
export async function readDemo(id: string) {
  const [row] = await db.select().from(prototypeRunsTable).where(eq(prototypeRunsTable.id, id));
  return row ? GetPrototypeRunResponse.parse(row.state) : null;
}
export async function saveDemo(previous: DemoRun, next: DemoRun) {
  const rows = await db.update(prototypeRunsTable).set({ state: next, version: next.version,
    dueAt: next.dueAt ? new Date(next.dueAt) : null })
    .where(and(eq(prototypeRunsTable.id, previous.id), eq(prototypeRunsTable.version, previous.version))).returning();
  return rows.length > 0;
}
export async function createDemo() {
  const run = initialRun();
  await db.insert(prototypeRunsTable).values({ id: run.id, version: run.version, state: run, dueAt: new Date(run.dueAt!) });
  return run;
}
export async function tickPrototype() {
  const rows = await db.select().from(prototypeRunsTable)
    .where(and(isNotNull(prototypeRunsTable.dueAt), lte(prototypeRunsTable.dueAt, new Date()))).limit(50);
  for (const row of rows) {
    const old = GetPrototypeRunResponse.parse(row.state);
    await saveDemo(old, delayedRun(old, 40)); // CAS means concurrent workers cannot duplicate the alert.
  }
}
