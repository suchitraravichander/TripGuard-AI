import assert from "node:assert/strict";
import { initialRun, delayedRun, eventRun, selectedRun } from "../prototype.ts";
import { scenarios } from "./scenarios.ts";
import { GetPrototypeRunResponse } from "@workspace/api-zod";

const initial = initialRun();
const delayed = delayedRun(initial, 40);
const chosen = selectedRun(delayed, delayed.options[0]!.id, delayed.version);
for (const [id, event, level] of [
  ["S02", "cancellation", "Critical"],
  ["S03", "weather_warning", "High"],
] as const) {
  const expected = scenarios.find(s => s.id === id)!;
  const run = eventRun(chosen, event);
  GetPrototypeRunResponse.parse(run);
  assert.equal(run.riskLevel, level, expected.expected);
  assert.equal(run.delayMinutes, 0);
  assert.deepEqual(run.impacts.map(i => i.segmentId).sort(), [...expected.affected].sort());
  assert.equal(run.selectedOptionId, null);
  assert.deepEqual(run.options, []);
  assert.equal(run.dueAt, null);
  assert.equal(run.version, chosen.version + 1);
  assert.throws(() => selectedRun(run, chosen.selectedOptionId!, chosen.version), /STALE/);
  assert.throws(() => selectedRun(run, chosen.selectedOptionId!, run.version), /OPTION/);
  assert.equal(eventRun(run, event), run);
  assert.deepEqual(run.segments, initial.segments);
  assert.equal(run.itineraryJson, initial.itineraryJson);
  const cleared = delayedRun(run, 0);
  assert.equal(cleared.event, "delay");
  assert.equal(cleared.riskLevel, "Low");
  assert.deepEqual(cleared.impacts, []);
  assert.equal(cleared.alerts.at(-1)!.level, "info");
  if (event === "cancellation") {
    assert.equal(run.remainingMinutes, null);
    assert.equal(run.alerts.at(-1)!.level, "urgent");
    assert.match(run.reasoning, /No feasible replacement/);
  } else {
    assert.equal(run.remainingMinutes, 90);
    assert.match(run.reasoning, /not a flight cancellation/);
    assert.match(run.reasoning, /2026-12-04T05:00:00/);
  }
}
const warning = eventRun(initial, "weather_warning");
const forecast = eventRun(warning, "forecast");
assert.equal(forecast.riskLevel, "Low");
assert.deepEqual(forecast.impacts, []);
assert.match(forecast.reasoning, /not an official warning/);
for (const change of [{ origin: "DEL" }, { start: "2026-12-04T09:00:00+05:30" }]) {
  const irrelevant = eventRun({ ...initial, segments: initial.segments.map((s, i) => i === 0 ? { ...s, ...change } : s) }, "weather_warning");
  assert.equal(irrelevant.riskLevel, "Low");
  assert.deepEqual(irrelevant.impacts, []);
}
assert.equal(eventRun(initial, "cancellation").dueAt, null);
console.log("S02/S03 prototype events, forecast separation, relevance and stale selections passed.");
