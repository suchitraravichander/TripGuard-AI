export interface Scenario {
  id: string;
  name: string;
  input: Record<string, unknown>;
  expected: string;
  affected: string[];
  deadline: string | null;
  recovery: string;
  endState: string;
  supported: boolean;
}
// Independent expected outcomes. Synthetic timestamps and facts, not live claims.
export const scenarios: Scenario[] = [
  { id: "S01", name: "Flight delay", input: { flight: "EX101", delayMinutes: 40, mctMinutes: 90, tier: "C" },
    expected: "High; 50-minute connection at risk, not confirmed missed.",
    affected: ["seg_002", "seg_003", "seg_004"], deadline: null,
    recovery: "Ask constraints before ranking; then respect budget and arrival deadline.",
    endState: "NEEDS_INPUT", supported: true },
  { id: "S02", name: "Flight cancellation", input: { flight: "EX101", status: "cancelled", delayMinutes: 0 },
    expected: "Critical even without a delay value; warn before searching alternatives.",
    affected: ["seg_002", "seg_003", "seg_004"], deadline: null,
    recovery: "Search replacement flights; do not cancel downstream bookings.",
    endState: "AWAITING_SELECTION or NO_FEASIBLE_OPTIONS", supported: false },
  { id: "S03", name: "Weather warning", input: { airport: "MAA", official: true, warning: "severe thunderstorms",
    validFrom: "2026-12-04T05:00:00+05:30", validTo: "2026-12-04T08:00:00+05:30", flightDeparture: "2026-12-04T06:10:00+05:30" },
    expected: "High weather exposure; do not claim flight cancellation or confirmed downstream loss.",
    affected: ["seg_001"], deadline: null,
    recovery: "Monitor flight status and explain contingency options.",
    endState: "ACTION_REQUIRED", supported: false },
  { id: "S04", name: "Missed connection", input: { flight: "EX101", delayMinutes: 100 },
    expected: "Critical; arrival after onward departure; urgent alert.",
    affected: ["seg_002", "seg_003", "seg_004"], deadline: null,
    recovery: "Seek replacement journey; same-booking protection remains unverified.",
    endState: "NEEDS_INPUT", supported: true },
  { id: "S05", name: "Terminal change", input: { flight: "EX212", previousTerminal: "T2", terminal: "T4",
    departure: "2026-12-04T14:40:00+08:00", observedAt: "2026-12-04T13:20:00+08:00",
    transferMinutes: null },
    expected: "Urgent terminal-change alert within two hours; transfer feasibility unknown.",
    affected: ["seg_002"], deadline: "2026-12-04T14:40:00+08:00",
    recovery: "Direct traveller to official terminal guidance; invent no transfer time.",
    endState: "ACTION_REQUIRED", supported: false },
  { id: "S06", name: "Train disruption", input: { train: "TR101", status: "cancelled", dependentFlight: "EX101",
    railArrivalScheduled: "2026-12-04T04:30:00+05:30" },
    expected: "Critical cancelled train; flight access at risk, not a cancelled flight.",
    affected: ["train_001", "seg_001"], deadline: null,
    recovery: "Compare ground alternatives using sourced duration and airport cutoff.",
    endState: "RECOVERY_SEARCH", supported: false },
  { id: "S07", name: "Hotel check-in impact", input: { hotel: "seg_003",
    predictedHotelArrival: "2026-12-05T00:45:00+11:00", statedCutoff: "2026-12-05T00:00:00+11:00",
    lateArrivalConfirmed: false },
    expected: "Hotel check-in at risk by 45 minutes; do not assert room loss.",
    affected: ["seg_003"], deadline: "2026-12-05T00:00:00+11:00",
    recovery: "Prepare late-arrival message for manual sending; require confirmation.",
    endState: "MANUAL_HANDOFF", supported: false },
  { id: "S08", name: "No alternative available", input: { budget: 0,
    latestArrival: "2026-12-04T23:00:00+11:00", companions: "Solo" },
    expected: "Zero qualifying fixture offers; no invented or constraint-breaking options.",
    affected: [], deadline: null,
    recovery: "Offer carrier contact or ask permission to relax constraints.",
    endState: "NO_FEASIBLE_OPTIONS", supported: true },
  { id: "S09", name: "API unavailable", input: { providerFailure: "timeout" },
    expected: "Record coverage failure; no fresh assessment or fabricated alert.",
    affected: [], deadline: null,
    recovery: "Disclose missing coverage; bounded retry and official-source handoff.",
    endState: "ACTIVE with UNAVAILABLE coverage", supported: true },
  { id: "S10", name: "False alarm", input: { flight: "EX101", delayMinutes: 0,
    mctMinutes: 90, scheduledLayoverMinutes: 90 },
    expected: "Low risk at exact minimum; no disruption alert and no affected downstream bookings.",
    affected: [], deadline: null,
    recovery: "Continue monitoring; no recovery needed.",
    endState: "WATCHING", supported: true },
];
