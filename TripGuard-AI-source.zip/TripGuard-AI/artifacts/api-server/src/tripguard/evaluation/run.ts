import assert from "node:assert/strict";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { assess, extractBookings, notify, recovery, runHero } from "../engine.ts";
import { TripRuntime, type Provider } from "../runtime.ts";
import { observedAt, delayedFeed } from "../fixtures.ts";
import { scenarios } from "./scenarios.ts";

const results: { id: string; status: string; evidence: string }[] = [];
let detectionCorrect = 0, detectionEvaluated = 0, impactCorrect = 0, impactEvaluated = 0;
let unnecessaryAlerts = 0, negativeCases = 0;
const trip = extractBookings();
const directory = await mkdtemp(join(tmpdir(), "tripguard-eval-"));
try {
  for (const s of scenarios) {
    if (!s.supported) {
      results.push({ id: s.id, status: "NOT_IMPLEMENTED",
        evidence: "Scenario specified; current engine has no input/handler for this event. Not counted as a pass." });
      continue;
    }
    try {
      let evidence = "";
      if (["S01", "S04", "S10"].includes(s.id)) {
        const delay = Number(s.input.delayMinutes);
        const result = runHero(undefined, { ...delayedFeed, delayMinutes: delay });
        const risk = result.risk;
        const expectedLevel = s.id === "S01" ? "High" : s.id === "S04" ? "Critical" : "Low";
        detectionEvaluated++;
        if (risk.level === expectedLevel) detectionCorrect++;
        assert.equal(risk.level, expectedLevel);
        const affected = risk.classification === "unchanged" ? [] : ["seg_002", ...risk.consequences.map(c => c.segmentId)];
        impactEvaluated++;
        if (JSON.stringify([...affected].sort()) === JSON.stringify([...s.affected].sort())) impactCorrect++;
        assert.deepEqual([...affected].sort(), [...s.affected].sort());
        assert.equal(risk.classification, s.id === "S01" ? "at_risk" : s.id === "S04" ? "missed" : "unchanged");
        assert.equal(result.alert?.level ?? null, s.id === "S01" ? "action_recommended" : s.id === "S04" ? "urgent" : null);
        if (s.id === "S10") { negativeCases++; if (result.alert) unnecessaryAlerts++; }
        if (result.alert) assert.equal(notify(risk, [result.alert.key], observedAt), null);
        assert.equal(result.recovery.options.length, 0);
        evidence = `Actual ${risk.level}/${risk.classification}; exact affected set matches; alert policy and repeat suppression checked.`;
      } else if (s.id === "S08") {
        const outcome = recovery(s.input as unknown as Parameters<typeof recovery>[0]);
        assert.equal(outcome.options.length, 0);
        evidence = "Zero options returned for impossible constraints. NO_FEASIBLE_OPTIONS state and carrier handoff are not implemented.";
      } else {
        const provider: Provider = { mode: "simulation", async check() { throw new Error("Simulated provider timeout"); } };
        const runtime = new TripRuntime(join(directory, "failure.json"), provider);
        const state = await runtime.tick();
        assert.match(state.lastError!, /timeout/);
        assert.equal(state.result, null); assert.deepEqual(state.notifications, []);
        evidence = "Injected provider exception persisted; assessment null and no fabricated notification. Bounded retry policy not implemented.";
      }
      results.push({ id: s.id, status: ["S08", "S09"].includes(s.id) ? "PARTIAL" : "PASS", evidence });
    } catch (error) {
      results.push({ id: s.id, status: "FAIL", evidence: String(error) });
    }
  }
  // Recovery feasibility checks use only synthetic options; no live inventory claim.
  const options = recovery({ latestArrival: "2026-12-06T00:00:00+11:00", budget: 150, companions: "Solo" }).options;
  assert.ok(options.length > 0);
  assert.ok(options.every(o => o.cost <= 150 && Date.parse(o.arrival) <= Date.parse("2026-12-06T00:00:00+11:00")));
  assert.ok(options.every(o => o.availability === "unverified" && !o.booked));
  const metrics = {
    detection: { correct: detectionCorrect, evaluated: detectionEvaluated, totalScenarios: 10,
      scope: "Level classification on supported delay/missed/negative cases only; not production event recall." },
    impact: { exactSetMatches: impactCorrect, evaluated: impactEvaluated,
      scope: "Affected set includes connecting flight plus downstream consequences; severity tested separately." },
    alertTimeliness: { status: "NOT_MEASURED", reason: "No external delivery; fixture timestamp is not alert delivery time." },
    recoveryQuality: { feasibleSyntheticOptions: options.length, checkedOptions: options.length,
      usefulness: "NOT_MEASURED", liveAvailability: "NOT_VERIFIED" },
    taskCompletion: { verifiedEndToEnd: 0, scenarios: 10,
      reason: "Partial engine paths do not establish full workflow completion, manual handoff or verified recovery." },
    falseAlerts: { unnecessaryAlerts, evaluatedNegativeCases: negativeCases,
      caveat: "One negative boundary case is insufficient to estimate a real-world false-alert rate." },
  };
  const output = resolve(import.meta.dirname, "../../../../../generated-artifacts/tripguard");
  await mkdir(output, { recursive: true });
  const report = { generatedAt: new Date().toISOString(), synthetic: true, scenarios, results, metrics };
  await writeFile(join(output, "scenario-evaluation.json"), JSON.stringify(report, null, 2));
  const escape = (v: unknown) => String(v).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  await writeFile(join(output, "scenario-evaluation.html"), `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Travel Guardian evaluation</title><style>body{font:16px/1.6 system-ui;max-width:1050px;margin:40px auto;padding:20px;background:#f3f8f6;color:#183f37}article{background:white;padding:20px;margin:18px 0;border:1px solid #c3d6cd}pre{white-space:pre-wrap;overflow-wrap:anywhere}h2{color:#076654}</style><h1>Travel Guardian: 10-scenario evaluation</h1><p>Synthetic tests against the existing engine. PASS is a checked scenario slice, not full task completion. PARTIAL and NOT_IMPLEMENTED are not passes.</p><h2>Metrics</h2><pre>${escape(JSON.stringify(metrics, null, 2))}</pre>${scenarios.map(s => { const r = results.find(r => r.id === s.id)!; return `<article><h2>${s.id}: ${escape(s.name)}</h2><strong>${r.status}</strong><p>${escape(r.evidence)}</p><h3>Fixture input</h3><pre>${escape(JSON.stringify(s.input, null, 2))}</pre><p><b>Expected:</b> ${escape(s.expected)}</p><p><b>Affected:</b> ${escape(s.affected.join(", ") || "None")}</p><p><b>Decision deadline:</b> ${escape(s.deadline ?? "Unknown; do not invent")}</p><p><b>Recovery:</b> ${escape(s.recovery)}</p><p><b>Target end state:</b> ${escape(s.endState)}</p></article>`; }).join("")}</html>`);
  console.log(JSON.stringify({ results, metrics }, null, 2));
  if (results.some(r => r.status === "FAIL")) process.exitCode = 1;
} finally { await rm(directory, { recursive: true, force: true }); }
