import { createHash } from "node:crypto";
export interface Action {
  id: string; recipient: string; text: string; hash: string; previewTurn: number;
  version: number; status: "awaiting_approval" | "approved" | "stale";
  approvedAt: string | null;
}
const digest = (recipient: string, text: string) => createHash("sha256").update(JSON.stringify({recipient, text})).digest("hex");
export function preview(recipient: string, text: string, turn: number): Action {
  return { id: "draft-1", recipient, text, hash: digest(recipient, text), previewTurn: turn,
    version: 1, status: "awaiting_approval", approvedAt: null };
}
export function approve(action: Action, hash: string, turn: number, now: string): Action {
  if (turn <= action.previewTurn || hash !== action.hash || digest(action.recipient, action.text) !== hash)
    throw new Error("Approval must match the exact preview in a later turn");
  return { ...action, status: "approved", approvedAt: now };
}
export function revise(action: Action, text: string): Action {
  return { ...action, text, hash: digest(action.recipient, text), version: action.version + 1,
    status: "stale", approvedAt: null };
}
export function execute(_action: Action): never {
  throw new Error("External execution disabled: read-only connector policy. Traveller must send or book directly.");
}
