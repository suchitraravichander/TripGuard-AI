import { mailbox, baseline, delayedFeed, recoveryFixtures, observedAt } from "./fixtures.ts";

export interface Segment {
  id: string;
  type: "flight" | "hotel" | "prepaid_transfer";
  provider: string;
  bookingId: string;
  service: string | null;
  start: string;
  end: string | null;
  startZone: string;
  endZone: string | null;
  origin: string;
  destination: string;
  source: { id: string; sentAt: string };
  fare: null;
  cost: { amount: number; currency: string } | null;
  refundable: string;
  airportExitMinutes: number | null;
  driverWaitMinutes: number | null;
  hotelCutoff: string | null;
}
export interface Trip {
  segments: Segment[];
  nodes: { id: string; type: string; date?: string }[];
  edges: { from: string; to: string; type: string }[];
  ignoredMessages: string[];
  flags: string[];
  disclosure: string;
}
export function extractBookings(messages = mailbox): Trip {
  const segments: Segment[] = [];
  const ignoredMessages: string[] = [];
  const flags: string[] = [];
  for (const message of messages) {
    const data: Record<string, string> = {};
    for (const line of message.body.split("\n")) {
      const match = /^([A-Za-z]+): (.+)$/.exec(line);
      if (match) data[match[1]!] = match[2]!;
    }
    if (!["flight", "hotel", "prepaid_transfer"].includes(data.Type ?? "")) {
      ignoredMessages.push(message.id);
      continue;
    }
    if (!data.Start || !/^\d{4}-\d{2}-\d{2}T.*[+-]\d{2}:\d{2}$/.test(data.Start) ||
        !Number.isFinite(Date.parse(data.Start))) {
      flags.push("date_ambiguous");
      continue;
    }
    if (!data.Provider || !data.Confirmation || !data.Origin || !data.Destination || !data.StartZone) {
      flags.push("incomplete");
      continue;
    }
    segments.push({
      id: `seg_${String(segments.length + 1).padStart(3, "0")}`,
      type: data.Type as Segment["type"], provider: data.Provider,
      bookingId: `${data.Provider}:${data.Confirmation}`, service: data.Service ?? null,
      start: data.Start, end: data.End ?? null,
      startZone: data.StartZone, endZone: data.EndZone ?? null,
      origin: data.Origin, destination: data.Destination,
      source: { id: message.id, sentAt: message.sentAt }, fare: null,
      cost: data.Cost ? { amount: Number(data.Cost), currency: data.Currency! } : null,
      refundable: data.Refundable ?? "unknown",
      airportExitMinutes: null, driverWaitMinutes: null, hotelCutoff: null,
    });
  }
  const nodes: Trip["nodes"] = segments.map(s => ({ id: s.id, type: s.type }));
  const edges: Trip["edges"] = [];
  const flights = segments.filter(s => s.type === "flight");
  if (flights.length >= 2) {
    nodes.push({ id: "layover_sin", type: "layover" });
    edges.push({ from: flights[0]!.id, to: flights[1]!.id, type: "connection" });
  }
  const hotel = segments.find(s => s.type === "hotel");
  const transfer = segments.find(s => s.type === "prepaid_transfer");
  const arrival = flights.at(-1);
  if (arrival && transfer) edges.push({ from: arrival.id, to: transfer.id, type: "transfer_pickup" });
  if (hotel) {
    if (arrival) edges.push({ from: arrival.id, to: hotel.id, type: "hotel_checkin" });
    const first = Date.parse(hotel.start.slice(0, 10));
    const last = hotel.end ? Date.parse(hotel.end.slice(0, 10)) : first;
    for (let day = first; day < last; day += 86400000) {
      const date = new Date(day).toISOString().slice(0, 10);
      const id = `night_${date}`;
      nodes.push({ id, type: "hotel_night", date });
      edges.push({ from: hotel.id, to: id, type: "night_coverage" });
    }
  }
  return { segments, nodes, edges, ignoredMessages, flags,
    disclosure: "Synthetic mailbox only. Gmail was not searched. Instruction-bearing unsupported messages were ignored." };
}

export type Feed = typeof delayedFeed;
export function monitor(previous: Feed | null, current: Feed) {
  return {
    checkedAt: current.observedAt, source: current.source, reliability: "simulated",
    changes: previous && previous.delayMinutes === current.delayMinutes ? [] : [
      { segmentId: "seg_001", type: "time_moved", from: previous?.delayMinutes ?? null,
        to: current.delayMinutes, minutes: current.delayMinutes - (previous?.delayMinutes ?? 0),
        observedAt: current.observedAt },
    ],
    notChecked: [{ segmentId: "seg_002", reason: "No approved live status source connected" }],
    weather: { category: "thunderstorms", kind: "forecast", officialWarning: false,
      observedAt: "2026-12-03T23:30:00Z", source: "Synthetic forecast" },
  };
}

export function assess(trip: Trip, delayMinutes: number, tier: "A" | "B" | "C" = "C", minimum = 90) {
  const inbound = trip.segments.find(s => s.service === "EX101")!;
  const onward = trip.segments.find(s => s.service === "EX212")!;
  const scheduledLayover = (Date.parse(onward.start) - Date.parse(inbound.end!)) / 60000;
  const remaining = scheduledLayover - delayMinutes;
  const threatened = remaining < minimum;
  const missed = remaining <= 0;
  return {
    level: missed ? "Critical" : threatened ? "High" : "Low",
    confidence: tier === "A" ? "high" : "medium",
    classification: missed || (threatened && tier === "A") ? "missed" : threatened ? "at_risk" : "unchanged",
    rules: missed ? ["R1a"] : threatened ? ["R1"] : [],
    delayMinutes, scheduledLayover, remaining, minimum, tier,
    predictedArrival: new Date(Date.parse(inbound.end!) + delayMinutes * 60000).toISOString(),
    basis: tier === "A" ? "Authoritative minimum" : "Planning minimum; not an airline rule",
    deadline: null,
    consequences: threatened ? [
      { segmentId: "seg_004", classification: "at_risk", amount: 65, currency: "AUD",
        reason: "A later replacement arrival could miss the pickup; revised arrival and wait allowance unknown." },
      { segmentId: "seg_003", classification: "at_risk", amount: null, currency: null,
        reason: "Amount unknown. Hotel arrival, transfer duration and late-arrival cutoff unknown; room loss not confirmed." },
    ] : [],
    protection: inbound.bookingId === onward.bookingId
      ? "Same booking; protection and rebooking terms unverified" : "Separate bookings; protection unverified",
    returnJourney: "No return booking in the file",
  };
}
export interface Constraints { latestArrival: string; budget: number; companions: string }
type RecoveryOption = (typeof recoveryFixtures)[number] & {
  checkedAt: string; source: string; currency: string; availability: string; booked: boolean;
};
export function recovery(constraints: Constraints | null): { question: string | null; options: RecoveryOption[] } {
  if (!constraints) return { question: "What is your latest acceptable arrival, budget, and who is travelling?", options: [] };
  if (!Number.isFinite(Date.parse(constraints.latestArrival)) || !Number.isFinite(constraints.budget) || constraints.budget < 0)
    throw new Error("Invalid recovery constraints");
  return {
    question: null,
    options: recoveryFixtures
      .filter(o => Date.parse(o.arrival) <= Date.parse(constraints.latestArrival) && o.cost <= constraints.budget)
      .sort((a, b) => a.brokenItems - b.brokenItems || Date.parse(a.arrival) - Date.parse(b.arrival) || a.cost - b.cost)
      .map(o => ({ ...o, checkedAt: observedAt, source: "Synthetic recovery fixture",
        currency: "AUD", availability: "unverified", booked: false })),
  };
}
export interface Notification { key: string; level: string; text: string; observedAt: string; delivery: "recorded_only" }
export function notify(risk: ReturnType<typeof assess>, seen: string[], time: string): Notification | null {
  if (!["High", "Critical"].includes(risk.level)) return null;
  const key = `seg_001|delay|${risk.delayMinutes}|${risk.level}`;
  if (seen.includes(key)) return null;
  return { key, level: risk.level === "Critical" ? "urgent" : "action_recommended",
    observedAt: time, delivery: "recorded_only",
    text: `Simulated: EX101 delayed ${risk.delayMinutes} minutes; predicted Singapore layover ${risk.remaining} minutes versus ${risk.minimum}-minute planning minimum (not an airline rule). Connection and downstream transfer are at risk. Compare recovery options. Decision deadline unknown. Source: simulated carrier status, ${time}. Not delivered externally.` };
}
export function runHero(previous: Feed = baseline, current: Feed = delayedFeed, seen: string[] = []) {
  const trip = extractBookings();
  const snapshot = monitor(previous, current);
  const risk = assess(trip, current.delayMinutes);
  const next = recovery(null);
  const alert = notify(risk, seen, current.observedAt);
  return { mode: "simulation" as const, trip, snapshot, risk,
    recovery: next, alert, actions: [],
    reply: `Change: EX101 delayed ${current.delayMinutes} minutes. ${alert?.text ?? "No new alert."} ${next.question}`,
    constraints: null };
}
