# TripGuard AI — source export

This ZIP is a snapshot of the current Replit project, not a GitHub download.
It includes the working web app, API server, shared libraries, design mockups,
tests, technical documentation, package manifests and lockfile.

## Requirements and configuration
- Node.js 24 and pnpm (this project uses a pnpm workspace).
- PostgreSQL for saved prototype trips. Configure DATABASE_URL separately
  using your host's secrets settings; no credentials are included.
- The web service expects PORT and BASE_PATH. The API expects its own PORT.
- Replit supplies artifact routing. On another host, configure same-origin
  /api routing to the API server and serve the frontend at its configured base.
- No live flight/weather feeds or external message delivery are bundled.

## Useful workspace commands
    pnpm install --frozen-lockfile
    pnpm run typecheck:libs
    pnpm --filter @workspace/tripguard typecheck
    pnpm --filter @workspace/api-server typecheck
    pnpm --filter @workspace/api-server test:hero

Review lib/db and its package scripts before setting up a new database.
Do not point schema setup at an existing production database unintentionally.
The artifact manifests and package scripts describe the service build/run setup.

## Excluded
Secrets and environment files; databases and saved runtime records; node_modules;
compiled build outputs; Git history; agent memory, conversations and internal
workspace state; uploaded reference files; generated reports and archives.
Source-generated API contracts are included. Mockup discovery indexes regenerate.

Nothing has been pushed or modified on GitHub. Keep credentials out of source
control and follow your organization's approval process for sharing this code.
