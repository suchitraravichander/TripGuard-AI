# TripGuard AI

Evidence-safe travel disruption reasoning, starting with a synthetic Chennai–Singapore–Sydney integration scenario.

## Run & Operate

- `artifacts/tripguard` is the interactive synthetic prototype at `/`.
- `POST /api/prototype/runs` extracts the bundled mock email into a persisted demo run. The API worker injects a delay after eight seconds; the browser polls for in-app alerts.
- Prototype runs are stored separately in PostgreSQL; the original offline hero harness and file-based simulation remain untouched. Recovery choices are saved, never booked. Only fictional sample input is accepted.

- `pnpm --filter @workspace/api-server test:hero` — execute offline hero integration criteria and generate the downloadable report.
- `docs/tripguard/reconciled-contract.md` — implemented scope, reconciled rules and live-source blockers.
- API starts a one-minute **simulation-only** worker. It never sends notifications or changes bookings.

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Product

_Describe the high-level user-facing capabilities of this app once they exist._

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
