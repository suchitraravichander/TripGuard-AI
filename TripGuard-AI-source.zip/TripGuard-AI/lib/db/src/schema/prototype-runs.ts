import { pgTable, text, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
export const prototypeRunsTable = pgTable("tripguard_prototype_runs", {
  id: text("id").primaryKey(),
  version: integer("version").notNull(),
  dueAt: timestamp("due_at", { withTimezone: true }),
  state: jsonb("state").notNull(),
});
